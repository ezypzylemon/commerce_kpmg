import praw
import os
from dotenv import load_dotenv
import pandas as pd
import matplotlib.pyplot as plt
from textblob import TextBlob
from wordcloud import WordCloud

# .env 파일에서 환경 변수 로드
load_dotenv()

# Reddit API 설정
reddit = praw.Reddit(
    client_id=os.getenv('CLIENT_ID'),
    client_secret=os.getenv('CLIENT_SECRET'),
    user_agent=os.getenv('USER_AGENT'),
    username=os.getenv('USERNAME'),
    password=os.getenv('PASSWORD')
)

# 패션 관련 서브레딧 'fashion'에서 streetwear 키워드로 게시물 검색
subreddit = reddit.subreddit('fashion')

def fetch_posts(keyword, limit=100):
    posts = []
    for submission in subreddit.search(keyword, limit=limit, sort='new', time_filter='all'):
        posts.append({
            'title': submission.title,
            'text': submission.selftext,
            'score': submission.score,
            'author': str(submission.author),
            'url': submission.url,
            'created_utc': submission.created_utc
        })
    return pd.DataFrame(posts)

# 데이터 수집
posts = fetch_posts('streetwear')

# 게시물 시간 데이터를 사용해 시간대별 분석
posts['timestamp'] = pd.to_datetime(posts['created_utc'], unit='s')
posts['hour'] = posts['timestamp'].dt.hour

# 시간대별 게시물 수 시각화
plt.figure(figsize=(10, 6))
posts.groupby('hour').size().plot(kind='bar')
plt.title('Posts per Hour')  # 제목을 영어로 변경
plt.xlabel('Hour of Day')  # X축 레이블을 영어로 변경
plt.ylabel('Number of Posts')  # Y축 레이블을 영어로 변경
plt.xticks(rotation=0)
plt.show()

# 게시물 제목 및 본문에서 자주 등장하는 키워드 추출 (WordCloud)
all_text = ' '.join(posts['title'].fillna('') + ' ' + posts['text'].fillna(''))
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_text)

# WordCloud 출력
plt.figure(figsize=(10, 6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.show()

# 감성 분석 (긍정적/부정적 분석)
def sentiment_analysis(text):
    blob = TextBlob(text)
    return blob.sentiment.polarity

# 각 게시물의 감성 분석 결과 추가
posts['sentiment'] = posts['text'].apply(sentiment_analysis)

# 긍정적/부정적 트렌드 요약
positive_trends = posts[posts['sentiment'] > 0]
negative_trends = posts[posts['sentiment'] < 0]
neutral_trends = posts[posts['sentiment'] == 0]

print(f"Positive trends: {len(positive_trends)} posts")
print(f"Negative trends: {len(negative_trends)} posts")
print(f"Neutral trends: {len(neutral_trends)} posts")

# 감성 분석 분포 시각화
plt.figure(figsize=(10, 6))
posts['sentiment'].hist(bins=50)
plt.title('Sentiment Distribution')  # 제목을 영어로 변경
plt.xlabel('Sentiment Score')  # X축 레이블을 영어로 변경
plt.ylabel('Number of Posts')  # Y축 레이블을 영어로 변경
plt.show()

# 결과 출력 (최고 점수를 받은 게시물 5개)
top_posts = posts.nlargest(5, 'score')
print("Top posts:")
print(top_posts[['title', 'score', 'author', 'sentiment']])
