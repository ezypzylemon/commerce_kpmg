from flask import Flask, render_template, request
import os
from dotenv import load_dotenv
import pandas as pd
import matplotlib.pyplot as plt
from textblob import TextBlob
from wordcloud import WordCloud
import praw
import faiss
import numpy as np
import time
from langchain_community.llms import OpenAI
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA

app = Flask(__name__)
load_dotenv()

openai_api_key = os.getenv("OPENAI_API_KEY")

reddit = praw.Reddit(
    client_id=os.getenv('CLIENT_ID'),
    client_secret=os.getenv('CLIENT_SECRET'),
    user_agent=os.getenv('USER_AGENT'),
    username=os.getenv('USERNAME'),
    password=os.getenv('PASSWORD')
)


def fetch_posts(keyword, limit=100):
    subreddit = reddit.subreddit('fashion')
    posts = []
    for submission in subreddit.search(keyword, limit=limit, sort='new', time_filter='all'):
        posts.append({
            'title': submission.title,
            'text': submission.selftext,
            'score': submission.score,
            'author': str(submission.author),
            'url': submission.url,
            'created_utc': submission.created_utc
        })
    return pd.DataFrame(posts)


def get_openai_embeddings(text: str):
    if not text or text.strip() == "":
        return np.zeros(1536)
    try:
        import openai
        openai.api_key = openai_api_key
        response = openai.Embedding.create(
            model="text-embedding-ada-002",
            input=text
        )
        return np.array(response['data'][0]['embedding'])
    except Exception as e:
        print(f"Embedding error: {e}")
        return np.zeros(1536)


def create_faiss_index(posts):
    all_texts = posts['title'].fillna('') + " " + posts['text'].fillna('')
    all_texts = all_texts.apply(lambda x: x if x.strip() else "No content")

    embeddings_list = [get_openai_embeddings(text) for text in all_texts]
    embeddings_array = np.array(embeddings_list)

    d = embeddings_array.shape[1]
    index = faiss.IndexFlatL2(d)
    index.add(embeddings_array)

    faiss.write_index(index, 'faiss_index.index')
    pd.DataFrame({"text": all_texts}).to_csv("faiss_texts.csv", index=False)

    return index, all_texts


def load_faiss_index():
    texts_df = pd.read_csv("faiss_texts.csv")
    texts = texts_df["text"].tolist()
    index = faiss.read_index('faiss_index.index')

    embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
    vectorstore = FAISS.from_texts(texts, embeddings)
    return vectorstore


def run_trend_analysis(query, vectorstore):
    qa_chain = RetrievalQA.from_chain_type(
        llm=OpenAI(openai_api_key=openai_api_key, temperature=0),
        chain_type="stuff",
        retriever=vectorstore.as_retriever()
    )
    return qa_chain.run(query)


def sentiment_analysis(text):
    if not text or not isinstance(text, str):
        return 0.0
    try:
        blob = TextBlob(text)
        return blob.sentiment.polarity
    except:
        return 0.0


def analyze(posts):
    posts['timestamp'] = pd.to_datetime(posts['created_utc'], unit='s')
    posts['hour'] = posts['timestamp'].dt.hour

    plt.figure(figsize=(8, 4))
    posts.groupby('hour').size().plot(kind='bar')
    plt.title('Posts per Hour')
    plt.xlabel('Hour')
    plt.ylabel('Count')
    plt.tight_layout()
    plt.savefig('static/hourly.png')
    plt.close()

    all_text = ' '.join(posts['title'].fillna('') + ' ' + posts['text'].fillna(''))
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_text)
    plt.figure(figsize=(10, 4))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.tight_layout()
    plt.savefig('static/wordcloud.png')
    plt.close()

    posts['sentiment'] = posts['text'].apply(sentiment_analysis)
    pos = len(posts[posts['sentiment'] > 0])
    neg = len(posts[posts['sentiment'] < 0])
    neu = len(posts[posts['sentiment'] == 0])
    top_posts = posts.nlargest(5, 'score')[['title', 'score', 'author']].to_dict('records')
    return pos, neg, neu, top_posts


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        keyword = request.form['keyword']
        posts = fetch_posts(keyword)
        create_faiss_index(posts)
        vectorstore = load_faiss_index()
        analysis = run_trend_analysis(f"What are people saying about {keyword}?", vectorstore)
        pos, neg, neu, top_posts = analyze(posts)

        return render_template('result.html',
                               keyword=keyword,
                               analysis=analysis,
                               pos=pos, neg=neg, neu=neu,
                               top_posts=top_posts,
                               hour_img='static/hourly.png',
                               wordcloud_img='static/wordcloud.png')
    return render_template('index.html')


if __name__ == '__main__':
    os.makedirs("static", exist_ok=True)
    app.run(debug=True)
