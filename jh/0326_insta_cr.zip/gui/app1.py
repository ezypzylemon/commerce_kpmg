import openai
import faiss
import numpy as np
import pandas as pd
from dotenv import load_dotenv
import os
# 최신 버전의 langchain 패키지 사용
# 구버전 langchain 패키지만 사용
from langchain_community.llms import OpenAI
from langchain_community.embeddings import OpenAIEmbeddings

from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
import matplotlib.pyplot as plt
from textblob import TextBlob
from wordcloud import WordCloud
import praw
import time

# .env 파일에서 환경 변수 로드
load_dotenv()

# OpenAI API 키 설정
openai.api_key = os.getenv("OPENAI_API_KEY")

# Reddit API 설정
reddit = praw.Reddit(
    client_id=os.getenv('CLIENT_ID'),
    client_secret=os.getenv('CLIENT_SECRET'),
    user_agent=os.getenv('USER_AGENT'),
    username=os.getenv('USERNAME'),
    password=os.getenv('PASSWORD')
)

# 패션 관련 서브레딧 'fashion'에서 streetwear 키워드로 게시물 검색
subreddit = reddit.subreddit('fashion')

# 게시물 수집 함수
def fetch_posts(keyword, limit=100):
    posts = []
    for submission in subreddit.search(keyword, limit=limit, sort='new', time_filter='all'):
        posts.append({
            'title': submission.title,
            'text': submission.selftext,
            'score': submission.score,
            'author': str(submission.author),
            'url': submission.url,
            'created_utc': submission.created_utc
        })
    return pd.DataFrame(posts)

# 게시물 수집
posts = fetch_posts('streetwear')

# 데이터 전처리 및 텍스트 벡터화 (OpenAI Embeddings 사용)
def get_openai_embeddings(text: str):
    # API 요청 오류 방지를 위한 빈 문자열 체크
    if not text or text.strip() == "":
        return np.zeros(1536)  # text-embedding-ada-002 모델의 출력 차원

    try:
        # 구버전 OpenAI API 호출 방식 사용
        response = openai.Embedding.create(
            model="text-embedding-ada-002",
            input=text
        )
        embeddings = response['data'][0]['embedding']
        return np.array(embeddings)
    except Exception as e:
        print(f"Error getting embeddings: {e}")
        return np.zeros(1536)  # 오류 발생 시 기본값 반환

# FAISS 인덱스 생성 함수
def create_faiss_index(posts):
    # 게시물 제목과 본문을 결합하여 벡터화
    all_texts = posts['title'].fillna('') + " " + posts['text'].fillna('')
    
    # 빈 문자열 처리
    all_texts = all_texts.apply(lambda x: x if x.strip() else "No content")
    
    print(f"Generating embeddings for {len(all_texts)} posts...")
    embeddings_list = []
    
    # API 요청 제한을 고려한 배치 처리
    for i, text in enumerate(all_texts):
        if i > 0 and i % 50 == 0:
            print(f"Processed {i}/{len(all_texts)} embeddings...")
            time.sleep(1)  # API 요청 제한을 피하기 위한 간격
        
        embeddings_list.append(get_openai_embeddings(text))
    
    embeddings_array = np.array(embeddings_list)
    
    # FAISS 인덱스 생성
    d = embeddings_array.shape[1]  # 벡터 차원
    index = faiss.IndexFlatL2(d)  # L2 거리 기준 인덱스 생성
    index.add(embeddings_array)  # 벡터 데이터 추가

    # 인덱스를 파일로 저장
    faiss.write_index(index, 'faiss_index.index')
    
    # 원본 텍스트도 저장하여 나중에 참조할 수 있게 함
    pd.DataFrame({"text": all_texts}).to_csv("faiss_texts.csv", index=False)
    
    print("FAISS Index created and saved successfully.")
    return index, all_texts

# FAISS 인덱스 생성
index, all_texts = create_faiss_index(posts)

# FAISS 인덱스를 로드하여 검색 준비
def load_faiss_index():
    try:
        # 저장된 텍스트 데이터 로드
        texts_df = pd.read_csv("faiss_texts.csv")
        texts = texts_df["text"].tolist()
        
        # FAISS 인덱스 파일 로드
        index = faiss.read_index('faiss_index.index')
        
        try:
            # OpenAI 임베딩 객체 생성 (API 키 직접 전달)
            embeddings = OpenAIEmbeddings(
                openai_api_key=os.getenv('OPENAI_API_KEY'),
                model="text-embedding-ada-002"  # 명시적으로 모델 지정
            )
            
            # FAISS 벡터 저장소 생성
            vectorstore = FAISS.from_texts(texts, embeddings)
            
            print("FAISS Index loaded successfully.")
            return vectorstore
        except Exception as e:
            print(f"Error with OpenAI embeddings: {e}")
            print("Trying to use existing index without embeddings...")
            
            # 대체 방법: 기존 벡터 데이터 사용
            class FaissWrapper:
                def __init__(self, index):
                    self.index = index
                def as_retriever(self):
                    return self
                def get_relevant_documents(self, query):
                    # 간단한 스텁 구현
                    return [{"page_content": "No retrieval available", "metadata": {}}]
            
            print("Created simple wrapper for FAISS index.")
            return FaissWrapper(index)
    except Exception as e:
        print(f"Error loading FAISS index: {e}")
        return None

# 인덱스를 로드하여 검색 준비
vectorstore = load_faiss_index()

# RetrievalQA 체인 설정 - vectorstore가 없으면 건너뜀
qa_chain = None
if vectorstore:
    try:
        qa_chain = RetrievalQA.from_chain_type(
            llm=OpenAI(openai_api_key=os.getenv("OPENAI_API_KEY"), temperature=0), 
            chain_type="stuff", 
            retriever=vectorstore.as_retriever()
        )
    except Exception as e:
        print(f"Error setting up QA chain: {e}")
        print("Using GPT-3.5 model directly for analysis instead of RetrievalQA")

# 질의 응답 처리
def run_trend_analysis(query: str):
    if not qa_chain:
        print("QA chain not available. Skipping trend analysis.")
        return "QA chain not initialized properly. Please check the setup."
        
    try:
        # 구버전 langchain (run 메서드 사용)
        try:
            response = qa_chain.run(query)
            print("Analysis:", response)
            return response
        except AttributeError as e:
            print(f"Method error: {e}")
            try:
                # 일부 다른 버전 langchain (invoke 메서드 사용)
                response = qa_chain.invoke(query)
                print("Analysis:", response)
                return response
            except Exception as e2:
                print(f"Alternative method error: {e2}")
                return "메서드 호출 오류. 라이브러리 버전 문제일 수 있습니다."
    except Exception as e:
        print(f"Error in trend analysis: {e}")
        return f"분석 중 오류가 발생했습니다: {str(e)}"

# QA 체인이 설정된 경우에만 예시 실행
if qa_chain:
    try:
        run_trend_analysis("streetwear fashion trends")
    except Exception as e:
        print(f"Failed to run trend analysis: {e}")

# 데이터 수집 및 분석 처리 함수
def collect_and_analyze_data():
    # 게시물 시간 데이터를 사용해 시간대별 분석
    posts['timestamp'] = pd.to_datetime(posts['created_utc'], unit='s')
    posts['hour'] = posts['timestamp'].dt.hour

    # 시간대별 게시물 수 시각화
    plt.figure(figsize=(10, 6))
    posts.groupby('hour').size().plot(kind='bar')
    plt.title('Posts per Hour')
    plt.xlabel('Hour of Day')
    plt.ylabel('Number of Posts')
    plt.xticks(rotation=0)
    plt.savefig('hourly_posts.png')
    plt.close()  # 리소스 해제

    # 게시물 제목 및 본문에서 자주 등장하는 키워드 추출 (WordCloud)
    all_text = ' '.join(posts['title'].fillna('') + ' ' + posts['text'].fillna(''))
    if all_text.strip():  # 빈 문자열이 아닌 경우에만 처리
        wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_text)

        # WordCloud 출력
        plt.figure(figsize=(10, 6))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.savefig('wordcloud.png')
        plt.close()  # 리소스 해제

    # 감성 분석 (긍정적/부정적 분석)
    def sentiment_analysis(text):
        if not text or not isinstance(text, str):
            return 0.0
        try:
            blob = TextBlob(text)
            return blob.sentiment.polarity
        except Exception as e:
            print(f"감성 분석 오류: {e}")
            return 0.0

    # 각 게시물의 감성 분석 결과 추가
    posts['sentiment'] = posts['text'].apply(sentiment_analysis)

    # 긍정적/부정적 트렌드 요약
    positive_trends = posts[posts['sentiment'] > 0]
    negative_trends = posts[posts['sentiment'] < 0]
    neutral_trends = posts[posts['sentiment'] == 0]

    print(f"Positive trends: {len(positive_trends)} posts")
    print(f"Negative trends: {len(negative_trends)} posts")
    print(f"Neutral trends: {len(neutral_trends)} posts")

    # 감성 분석 분포 시각화
    plt.figure(figsize=(10, 6))
    posts['sentiment'].hist(bins=50)
    plt.title('Sentiment Distribution')
    plt.xlabel('Sentiment Score')
    plt.ylabel('Number of Posts')
    plt.savefig('sentiment_distribution.png')
    plt.close()  # 리소스 해제

    # 결과 출력 (최고 점수를 받은 게시물 5개)
    top_posts = posts.nlargest(5, 'score')
    print("Top posts:")
    print(top_posts[['title', 'score', 'author', 'sentiment']])

    return {
        "positive_count": len(positive_trends),
        "negative_count": len(negative_trends),
        "neutral_count": len(neutral_trends),
        "top_posts": top_posts[['title', 'score', 'author', 'sentiment']].to_dict('records')
    }

# 데이터 수집 및 분석 실행
if __name__ == "__main__":
    collect_and_analyze_data()