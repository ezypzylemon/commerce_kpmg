import certifi, os
os.environ['SSL_CERT_FILE'] = certifi.where()
import snscrape.modules.twitter as sntwitter
import pandas as pd

# 사용자에게 키워드 입력 받기여름
keyword = input("수집할 해시태그 또는 키워드를 입력하세요 (예: 여름코디): ").strip()
max_posts = 100  # 수집할 트윗 수

query = f'#{keyword} since:2024-12-01 until:2025-03-01'  # 해시태그 검색 쿼리
tweets = []

print(f"🔍 '{keyword}' 관련 트윗 수집 중...")

for i, tweet in enumerate(sntwitter.TwitterSearchScraper(query).get_items()):
    if i >= max_posts:
        break
    tweets.append([
        tweet.date.strftime('%Y-%m-%d %H:%M:%S'),
        tweet.user.username,
        tweet.content,
        tweet.likeCount,
        tweet.retweetCount,
        tweet.url
    ])

# DataFrame으로 변환
df = pd.DataFrame(tweets, columns=["날짜", "작성자", "본문", "좋아요 수", "리트윗 수", "URL"])

# CSV 저장
filename = f"twitter_{keyword}_trend.csv"
df.to_csv(filename, index=False, encoding='utf-8-sig')

print(f"✅ '{keyword}' 관련 트윗 {len(df)}개 저장 완료: {filename}")
