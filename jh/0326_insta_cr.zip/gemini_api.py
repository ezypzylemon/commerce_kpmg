import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os
import time
from tqdm import tqdm
import re
from PIL import Image
from io import BytesIO
import google.generativeai as genai
import base64
from collections import Counter
import numpy as np
import sys
sys.stdout.reconfigure(encoding='utf-8')


class InstagramGeminiAnalyzer:
    """
    Gemini API를 활용한 인스타그램 패션 트렌드 분석기
    
    웹 스크래핑 대신 LLM 기반 접근 방식을 활용하여 분석합니다.
    """
    
    def __init__(self, gemini_api_key):
        """
        초기화
        
        gemini_api_key: Google Gemini API 키
        """
        self.gemini_api_key = gemini_api_key
        genai.configure(api_key=gemini_api_key)
        
        # Gemini Pro 모델 초기화
        self.text_model = genai.GenerativeModel('gemini-2.0-flash')
        self.vision_model = genai.GenerativeModel('gemini-pro-vision')
        
        # 기본 헤더 설정
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
        }
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        # 데이터 저장 변수
        self.data = []
        self.images = []
        self.gemini_analyzed_trends = []
        
    def take_screenshot(self, url, filename=None):
        """
        웹페이지 스크린샷 캡처 (비로그인)
        참고: 이 함수는 Selenium 또는 유사한 도구가 필요합니다.
        """
        try:
            # 간략 버전: 실제 구현에서는 Selenium 사용 권장
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            
            driver = webdriver.Chrome(options=chrome_options)
            driver.get(url)
            
            # 페이지 로딩 대기
            time.sleep(5)
            
            if not filename:
                timestamp = int(time.time())
                filename = f"instagram_screenshot_{timestamp}.png"
            
            driver.save_screenshot(filename)
            driver.quit()
            
            return filename
        except Exception as e:
            print(f"스크린샷 캡처 오류: {e}")
            return None
    
    def collect_hashtag_screenshots(self, hashtags, screenshots_per_tag=3):
        """
        해시태그 페이지의 스크린샷 수집
        """
        screenshot_paths = []
        
        for hashtag in tqdm(hashtags, desc="해시태그 스크린샷 수집 중"):
            try:
                url = f"https://www.instagram.com/explore/tags/{hashtag}/"
                
                for i in range(screenshots_per_tag):
                    screenshot_filename = f"screenshots/{hashtag}_screenshot_{i}.png"
                    os.makedirs("screenshots", exist_ok=True)
                    
                    result = self.take_screenshot(url, screenshot_filename)
                    if result:
                        screenshot_paths.append({
                            "path": screenshot_filename,
                            "hashtag": hashtag,
                            "url": url
                        })
                    
                    # 다음 스크린샷 전 스크롤 처리 필요
                    time.sleep(2)
            except Exception as e:
                print(f"해시태그 '{hashtag}' 스크린샷 수집 오류: {e}")
        
        self.screenshots = screenshot_paths
        return screenshot_paths
    
    def analyze_screenshot_with_gemini(self, screenshot_path, prompt=None):
        """
        Gemini Pro Vision을 사용하여 스크린샷 분석
        """
        try:
            if not prompt:
                prompt = """
                이 인스타그램 스크린샷을 분석하고 패션 관련 정보를 추출해주세요.
                다음 정보를 추출해주세요:
                1. 보이는 주요 패션 아이템
                2. 주요 색상과 패턴
                3. 인식되는 스타일 (예: 캐주얼, 스트릿, 포멀 등)
                4. 주요 해시태그
                5. 현재 보이는 트렌드 요약
                
                JSON 형식으로 응답해주세요:
                {
                  "fashion_items": ["아이템1", "아이템2", ...],
                  "colors": ["색상1", "색상2", ...],
                  "patterns": ["패턴1", "패턴2", ...],
                  "styles": ["스타일1", "스타일2", ...],
                  "hashtags": ["해시태그1", "해시태그2", ...],
                  "trend_summary": "트렌드 요약"
                }
                """
            
            image = Image.open(screenshot_path)
            
            # Gemini에 이미지 및 프롬프트 전송
            response = self.vision_model.generate_content([prompt, image])
            
            # 응답에서 JSON 추출
            response_text = response.text
            json_match = re.search(r'{.*}', response_text, re.DOTALL)
            
            if json_match:
                json_str = json_match.group(0)
                analysis_result = json.loads(json_str)
                analysis_result["screenshot_path"] = screenshot_path
                return analysis_result
            else:
                print(f"JSON 응답을 찾을 수 없습니다: {response_text}")
                return None
            
        except Exception as e:
            print(f"Gemini 이미지 분석 오류: {e}")
            return None
    
    def analyze_fashion_text_with_gemini(self, text, query=None):
        """
        Gemini Pro를 사용하여 텍스트 기반 패션 트렌드 분석
        """
        try:
            if not query:
                query = f"""
                다음 텍스트에서 패션 트렌드 정보를 분석해주세요:
                
                {text}
                
                다음 정보를 추출해주세요:
                1. 주요 패션 키워드
                2. 언급된 브랜드
                3. 주요 아이템
                4. 색상 트렌드
                5. 스타일 트렌드
                
                JSON 형식으로 응답해주세요:
                {{
                  "keywords": ["키워드1", "키워드2", ...],
                  "brands": ["브랜드1", "브랜드2", ...],
                  "items": ["아이템1", "아이템2", ...],
                  "colors": ["색상1", "색상2", ...],
                  "styles": ["스타일1", "스타일2", ...]
                }}
                """
            
            response = self.text_model.generate_content(query)
            
            # 응답에서 JSON 추출
            response_text = response.text
            json_match = re.search(r'{.*}', response_text, re.DOTALL)
            
            if json_match:
                json_str = json_match.group(0)
                analysis_result = json.loads(json_str)
                return analysis_result
            else:
                print(f"JSON 응답을 찾을 수 없습니다: {response_text}")
                return None
        
        except Exception as e:
            print(f"Gemini 텍스트 분석 오류: {e}")
            return None
    
    def collect_fashion_blogs(self, keywords, blogs_per_keyword=3):
        """
        패션 블로그나 뉴스 기사에서 트렌드 정보 수집
        """
        fashion_texts = []
        
        for keyword in tqdm(keywords, desc="패션 콘텐츠 수집 중"):
            try:
                # 여기서는 예시로 네이버 블로그 검색을 사용
                # 실제로는 RSS 피드, 공식 API, 또는 허용된 웹사이트에서 수집해야 함
                search_url = f"https://search.naver.com/search.naver?where=blog&query={keyword}+패션+트렌드"
                
                response = self.session.get(search_url)
                if response.status_code != 200:
                    continue
                
                # 블로그 포스트 링크 추출 (간략 예시)
                blog_links = re.findall(r'<a href="(https://blog.naver.com/[^"]+)"', response.text)
                
                for link in blog_links[:blogs_per_keyword]:
                    blog_response = self.session.get(link)
                    if blog_response.status_code == 200:
                        # 콘텐츠 추출 (실제로는 더 정교한 파싱 필요)
                        content = re.sub(r'<[^>]+>', ' ', blog_response.text)
                        content = re.sub(r'\s+', ' ', content).strip()
                        
                        fashion_texts.append({
                            "source": link,
                            "keyword": keyword,
                            "content": content,
                            "date": datetime.now().strftime("%Y-%m-%d")
                        })
                    
                    time.sleep(1)  # 요청 간 딜레이
                
            except Exception as e:
                print(f"키워드 '{keyword}' 콘텐츠 수집 오류: {e}")
        
        self.blog_data = fashion_texts
        return fashion_texts
    
    def generate_fashion_trends_report(self, screenshot_analyses=None, text_analyses=None):
        """
        Gemini Pro를 활용하여 종합적인 패션 트렌드 보고서 생성
        """
        if not screenshot_analyses:
            screenshot_analyses = self.gemini_analyzed_trends
        
        if not text_analyses and hasattr(self, 'text_analyses'):
            text_analyses = self.text_analyses
        
        # 분석 데이터 준비
        analysis_data = {
            "screenshot_analyses": screenshot_analyses if screenshot_analyses else [],
            "text_analyses": text_analyses if text_analyses else []
        }
        
        analysis_json = json.dumps(analysis_data, ensure_ascii=False, indent=2)
        
        prompt = f"""
        다음 데이터는 인스타그램 및 패션 블로그에서 수집한 패션 트렌드 분석 결과입니다:
        
        {analysis_json}
        
        이 데이터를 기반으로 2025년 패션 트렌드에 대한 종합적인 보고서를 작성해주세요.
        다음 내용을 포함해야 합니다:
        
        1. 주요 트렌드 요약 (5가지)
        2. 인기 아이템 TOP 10
        3. 주요 색상 트렌드
        4. 주요 스타일 트렌드
        5. 시즌별 예측
        6. 인플루언서 영향
        7. 소비자 행동 분석
        8. 마케팅 전략 제안
        
        결과는 마크다운 형식으로 제공해주세요.
        """
        
        try:
            response = self.text_model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"트렌드 보고서 생성 오류: {e}")
            return None
    
    def process_all_screenshots(self):
        """
        모든 스크린샷 분석 처리
        """
        if not hasattr(self, 'screenshots') or not self.screenshots:
            print("분석할 스크린샷이 없습니다.")
            return []
        
        analyses = []
        
        for screenshot_info in tqdm(self.screenshots, desc="스크린샷 분석 중"):
            result = self.analyze_screenshot_with_gemini(screenshot_info["path"])
            if result:
                result["hashtag"] = screenshot_info["hashtag"]
                result["url"] = screenshot_info["url"]
                analyses.append(result)
            
            time.sleep(1)  # API 요청 사이 딜레이
        
        self.gemini_analyzed_trends = analyses
        return analyses
    
    def process_all_blog_texts(self):
        """
        모든 블로그 텍스트 분석 처리
        """
        if not hasattr(self, 'blog_data') or not self.blog_data:
            print("분석할 블로그 데이터가 없습니다.")
            return []
        
        text_analyses = []
        
        for blog_info in tqdm(self.blog_data, desc="블로그 텍스트 분석 중"):
            # 텍스트가 너무 길면 잘라서 분석
            content = blog_info["content"]
            if len(content) > 5000:  # 적절한 길이로 조정
                content = content[:5000]
            
            result = self.analyze_fashion_text_with_gemini(content)
            if result:
                result["source"] = blog_info["source"]
                result["keyword"] = blog_info["keyword"]
                result["date"] = blog_info["date"]
                text_analyses.append(result)
            
            time.sleep(1)  # API 요청 사이 딜레이
        
        self.text_analyses = text_analyses
        return text_analyses
    
    def aggregate_trends(self):
        """
        모든 분석 결과를 집계하여 종합적인 트렌드 도출
        """
        if not hasattr(self, 'gemini_analyzed_trends') or not self.gemini_analyzed_trends:
            print("집계할 이미지 분석 데이터가 없습니다.")
            return {}
        
        # 집계 변수 초기화
        all_fashion_items = []
        all_colors = []
        all_patterns = []
        all_styles = []
        all_hashtags = []
        
        # 스크린샷 분석 결과 집계
        for analysis in self.gemini_analyzed_trends:
            if "fashion_items" in analysis:
                all_fashion_items.extend(analysis["fashion_items"])
            if "colors" in analysis:
                all_colors.extend(analysis["colors"])
            if "patterns" in analysis:
                all_patterns.extend(analysis["patterns"])
            if "styles" in analysis:
                all_styles.extend(analysis["styles"])
            if "hashtags" in analysis:
                all_hashtags.extend(analysis["hashtags"])
        
        # 텍스트 분석 결과 추가 (있는 경우)
        if hasattr(self, 'text_analyses') and self.text_analyses:
            for analysis in self.text_analyses:
                if "items" in analysis:
                    all_fashion_items.extend(analysis["items"])
                if "colors" in analysis:
                    all_colors.extend(analysis["colors"])
                if "styles" in analysis:
                    all_styles.extend(analysis["styles"])
                if "keywords" in analysis:
                    all_hashtags.extend(analysis["keywords"])
        
        # 빈도 분석
        fashion_items_freq = Counter(all_fashion_items).most_common(20)
        colors_freq = Counter(all_colors).most_common(15)
        patterns_freq = Counter(all_patterns).most_common(10)
        styles_freq = Counter(all_styles).most_common(10)
        hashtags_freq = Counter(all_hashtags).most_common(30)
        
        # 결과 집계
        aggregated_trends = {
            "top_fashion_items": dict(fashion_items_freq),
            "top_colors": dict(colors_freq),
            "top_patterns": dict(patterns_freq),
            "top_styles": dict(styles_freq),
            "top_hashtags": dict(hashtags_freq)
        }
        
        return aggregated_trends
    
    def visualize_trends(self, trends_data=None, output_folder="trend_results"):
        """
        트렌드 분석 결과 시각화
        """
        if trends_data is None:
            trends_data = self.aggregate_trends()
        
        if not trends_data:
            print("시각화할 트렌드 데이터가 없습니다.")
            return
        
        os.makedirs(output_folder, exist_ok=True)
        
        # 그래프 한글 폰트 설정
        try:
            plt.rcParams['font.family'] = 'Malgun Gothic'
        except:
            print("한글 폰트 설정에 실패했습니다. 기본 폰트를 사용합니다.")
        
        # 1. 패션 아이템 Top 10 시각화
        if trends_data.get("top_fashion_items"):
            plt.figure(figsize=(12, 8))
            items = list(trends_data["top_fashion_items"].keys())[:10]
            values = list(trends_data["top_fashion_items"].values())[:10]
            
            plt.barh(items[::-1], values[::-1])
            plt.title("인기 패션 아이템 Top 10", fontsize=16)
            plt.xlabel("언급 빈도")
            plt.tight_layout()
            plt.savefig(f"{output_folder}/top_fashion_items.png")
            plt.close()
        
        # 2. 색상 트렌드 시각화
        if trends_data.get("top_colors"):
            plt.figure(figsize=(12, 8))
            colors = list(trends_data["top_colors"].keys())[:8]
            values = list(trends_data["top_colors"].values())[:8]
            
            # 색상 매핑 (실제 색상에 가깝게 표현)
            color_map = {
                "black": "#000000", "white": "#FFFFFF", "red": "#FF0000",
                "blue": "#0000FF", "green": "#00FF00", "yellow": "#FFFF00",
                "purple": "#800080", "pink": "#FFC0CB", "orange": "#FFA500",
                "brown": "#A52A2A", "gray": "#808080", "beige": "#F5F5DC",
                "navy": "#000080", "gold": "#FFD700", "silver": "#C0C0C0"
            }
            
            # 해당하는 색상 코드 찾기 (없으면 회색 사용)
            bar_colors = []
            for color_name in colors:
                color_key = next((k for k in color_map.keys() if k in color_name.lower()), None)
                bar_colors.append(color_map.get(color_key, "#808080"))
            
            plt.barh(colors[::-1], values[::-1], color=bar_colors[::-1])
            plt.title("인기 색상 트렌드", fontsize=16)
            plt.xlabel("언급 빈도")
            plt.tight_layout()
            plt.savefig(f"{output_folder}/color_trends.png")
            plt.close()
        
        # 3. 패션 스타일 시각화
        if trends_data.get("top_styles"):
            plt.figure(figsize=(12, 8))
            styles = list(trends_data["top_styles"].keys())
            values = list(trends_data["top_styles"].values())
            
            plt.barh(styles[::-1], values[::-1])
            plt.title("인기 패션 스타일", fontsize=16)
            plt.xlabel("언급 빈도")
            plt.tight_layout()
            plt.savefig(f"{output_folder}/style_trends.png")
            plt.close()
        
        # 4. 해시태그 빈도 시각화
        if trends_data.get("top_hashtags"):
            plt.figure(figsize=(14, 10))
            hashtags = list(trends_data["top_hashtags"].keys())[:15]
            values = list(trends_data["top_hashtags"].values())[:15]
            
            plt.barh(hashtags[::-1], values[::-1])
            plt.title("인기 해시태그", fontsize=16)
            plt.xlabel("언급 빈도")
            plt.tight_layout()
            plt.savefig(f"{output_folder}/hashtag_trends.png")
            plt.close()
        
        # 5. 워드클라우드 시각화
        try:
            from wordcloud import WordCloud
            
            if trends_data.get("top_hashtags"):
                plt.figure(figsize=(12, 8))
                wordcloud = WordCloud(width=800, height=500, 
                                     background_color='white',
                                     font_path='malgun.ttf',
                                     max_words=100).generate_from_frequencies(trends_data["top_hashtags"])
                plt.imshow(wordcloud, interpolation='bilinear')
                plt.axis('off')
                plt.tight_layout()
                plt.savefig(f"{output_folder}/hashtag_wordcloud.png")
                plt.close()
        except ImportError:
            print("워드클라우드 시각화를 위해 'pip install wordcloud'를 실행하세요.")
        
        print(f"시각화 결과가 '{output_folder}' 폴더에 저장되었습니다.")
    
    def save_to_csv(self, filename="gemini_analyzed_fashion_trends.csv"):
        """
        분석 결과를 CSV 파일로 저장
        """
        if not hasattr(self, 'gemini_analyzed_trends') or not self.gemini_analyzed_trends:
            print("저장할 분석 데이터가 없습니다.")
            return
        
        # 데이터프레임 생성을 위한 플랫 데이터 준비
        flat_data = []
        
        for analysis in self.gemini_analyzed_trends:
            row = {
                "hashtag": analysis.get("hashtag", ""),
                "url": analysis.get("url", ""),
                "fashion_items": ", ".join(analysis.get("fashion_items", [])),
                "colors": ", ".join(analysis.get("colors", [])),
                "patterns": ", ".join(analysis.get("patterns", [])),
                "styles": ", ".join(analysis.get("styles", [])),
                "hashtags": ", ".join(analysis.get("hashtags", [])),
                "trend_summary": analysis.get("trend_summary", "")
            }
            flat_data.append(row)
        
        df = pd.DataFrame(flat_data)
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"분석 결과가 '{filename}' 파일에 저장되었습니다.")


def main():
    """메인 실행 함수"""
    # Gemini API 키 설정
    gemini_api_key = "YOUR_GEMINI_API_KEY"  # 실제 사용 시 API 키 필요
    
    # 분석기 초기화
    analyzer = InstagramGeminiAnalyzer(gemini_api_key)
    
    # 패션 해시태그 설정
    fashion_hashtags = [
        'kfashion', 'ootd', 'koreanfashion', 'fashionstyle', 
        '패션스타그램', '데일리룩', 'fashiontrends2025'
    ]
    
    # 패션 키워드 설정 (블로그/뉴스 검색용)
    fashion_keywords = [
        '2025 패션트렌드', '한국패션', '스트릿패션', 
        '패션위크', '럭셔리패션', '지속가능패션'
    ]
    
    try:
        print("===== Gemini API를 활용한 인스타그램 패션 트렌드 분석 시작 =====")
        
        # 1. 해시태그 스크린샷 수집
        print("\n1. 인스타그램 해시태그 스크린샷 수집 중...")
        analyzer.collect_hashtag_screenshots(fashion_hashtags, screenshots_per_tag=2)
        
        # 2. 스크린샷 Gemini 분석
        print("\n2. 스크린샷 AI 분석 중...")
        analyzer.process_all_screenshots()
        
        # 3. 패션 블로그/뉴스 콘텐츠 수집
        print("\n3. 패션 블로그/뉴스 콘텐츠 수집 중...")
        analyzer.collect_fashion_blogs(fashion_keywords, blogs_per_keyword=2)
        
        # 4. 텍스트 Gemini 분석
        print("\n4. 텍스트 AI 분석 중...")
        analyzer.process_all_blog_texts()
        
        # 5. 트렌드 집계
        print("\n5. 패션 트렌드 집계 중...")
        aggregated_trends = analyzer.aggregate_trends()
        
        # 6. 시각화
        print("\n6. 트렌드 시각화 중...")
        analyzer.visualize_trends(aggregated_trends)
        
        # 7. 분석 결과 저장
        analyzer.save_to_csv()
        
        # 8. 종합 보고서 생성
        print("\n7. 패션 트렌드 종합 보고서 생성 중...")
        report = analyzer.generate_fashion_trends_report()
        
        if report:
            with open("fashion_trends_report.md", "w", encoding="utf-8") as f:
                f.write(report)
            print("패션 트렌드 보고서가 'fashion_trends_report.md' 파일에 저장되었습니다.")
        
        print("\n===== 패션 트렌드 분석 완료 =====")
        
    except Exception as e:
        print(f"\n오류 발생: {e}")


if __name__ == "__main__":
    main()