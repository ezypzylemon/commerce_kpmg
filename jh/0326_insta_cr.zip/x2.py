import snscrape.modules.twitter as sntwitter
import pandas as pd
import os
import certifi
os.environ['SSL_CERT_FILE'] = certifi.where()


# 사용자 입력 받기
keyword = input("수집할 키워드 (예: 여름코디): ").strip()
max_results = 100
start_date = "2024-12-01"
end_date = "2025-03-01"

# query에서 '#' 제거 + 트윗 언어 한글로 제한
query = f'{keyword} lang:ko since:{start_date} until:{end_date}'

print(f"🔍 '{keyword}' 관련 트윗 {max_results}개 수집 중...\n")

tweets = []
try:
    for i, tweet in enumerate(sntwitter.TwitterSearchScraper(query).get_items()):
        if i >= max_results:
            break
        tweets.append([
            tweet.date.strftime("%Y-%m-%d %H:%M:%S"),
            tweet.user.username,
            tweet.content,
            tweet.likeCount,
            tweet.retweetCount,
            tweet.url
        ])
except Exception as e:
    print(f"❌ 오류 발생: {e}")
    exit()

# DataFrame 저장
df = pd.DataFrame(tweets, columns=["날짜", "작성자", "본문", "좋아요", "리트윗", "URL"])

if df.empty:
    print("⚠️ 수집된 트윗이 없습니다. 키워드나 날짜 범위를 확인하세요.")
else:
    csv_file = f"{keyword}_트윗.csv"
    df.to_csv(csv_file, index=False, encoding="utf-8-sig")
    print(f"\n✅ 수집 완료! 결과 저장: {csv_file}")
