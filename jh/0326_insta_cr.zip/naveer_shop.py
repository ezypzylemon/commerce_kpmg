import requests
from bs4 import BeautifulSoup
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import re
from collections import Counter

def setup_driver():
    """Selenium 웹드라이버 설정"""
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--lang=ko-KR,ko")
    
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
    options.add_argument(f'user-agent={user_agent}')
    
    options.add_argument("--log-level=3")
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    return driver

def get_fashion_products_by_search(driver, keyword="패션"):
    """네이버 쇼핑 검색 결과 수집"""
    url = f"https://search.shopping.naver.com/search/all?query={keyword}&cat_id=&frm=NVSHATC"
    driver.get(url)
    
    # 페이지 로딩 대기
    time.sleep(5)
    
    # 무한 스크롤로 더 많은 상품 로드 (필요시)
    for _ in range(3):  # 3번 스크롤
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)
    
    # 상품 정보 추출
    products = []
    product_elements = driver.find_elements(By.CSS_SELECTOR, ".product_item")
    
    if not product_elements:
        # 대체 선택자 시도
        product_elements = driver.find_elements(By.CSS_SELECTOR, ".basicList_item__0T9JD")
    
    for item in product_elements[:50]:  # 상위 50개 상품만
        try:
            # 제품명
            title_elem = item.find_element(By.CSS_SELECTOR, ".basicList_title__VfX3c")
            title = title_elem.text.strip()
            
            # 가격
            price_elem = item.find_element(By.CSS_SELECTOR, ".price_num__S2p_v")
            price = price_elem.text.strip()
            
            # 쇼핑몰
            mall_elem = None
            try:
                mall_elem = item.find_element(By.CSS_SELECTOR, ".basicList_mall_title__FDXX5")
            except:
                try:
                    mall_elem = item.find_element(By.CSS_SELECTOR, ".basicList_mall_name__XQlSa")
                except:
                    pass
            
            mall = mall_elem.text.strip() if mall_elem else "Unknown"
            
            products.append({
                "title": title,
                "price": price,
                "mall": mall
            })
        except Exception as e:
            print(f"상품 파싱 오류: {e}")
            continue
    
    return pd.DataFrame(products)

def analyze_fashion_keywords(data_df):
    """패션 키워드 분석"""
    if data_df.empty:
        return {}
    
    # 제품명에서 키워드 추출
    all_words = []
    for title in data_df['title']:
        # 한글 단어 (2글자 이상) 추출
        korean_words = re.findall(r'[가-힣]{2,}', title)
        all_words.extend(korean_words)
    
    # 불용어 정의
    stopwords = ['상품', '제품', '판매', '세일', '할인', '무료', '배송', '당일', '오늘']
    filtered_words = [word for word in all_words if word not in stopwords]
    
    # 키워드 빈도 분석
    word_counts = Counter(filtered_words)
    
    # 가격 분석
    price_numbers = []
    for price in data_df['price']:
        # 숫자만 추출
        price_num = re.sub(r'[^0-9]', '', price)
        if price_num:
            price_numbers.append(int(price_num))
    
    avg_price = sum(price_numbers) / len(price_numbers) if price_numbers else 0
    
    return {
        'top_keywords': word_counts.most_common(20),
        'avg_price': avg_price
    }

def main():
    print("===== 네이버 쇼핑 패션 트렌드 분석 시작 =====")
    
    # 검색할 패션 키워드 목록
    fashion_keywords = ["봄패션", "여성패션", "남성패션", "데일리룩", "오피스룩"]
    
    # 웹드라이버 설정
    driver = setup_driver()
    
    try:
        all_products = []
        
        for keyword in fashion_keywords:
            print(f"\n'{keyword}' 관련 상품 수집 중...")
            products = get_fashion_products_by_search(driver, keyword)
            
            if not products.empty:
                products['keyword'] = keyword
                all_products.append(products)
                print(f"- {len(products)}개 상품 수집 완료")
            else:
                print(f"- 상품을 찾을 수 없습니다.")
        
        # 모든 데이터 합치기
        if all_products:
            combined_df = pd.concat(all_products)
            
            # 데이터 저장
            combined_df.to_csv("naver_fashion_products.csv", index=False, encoding="utf-8-sig")
            print(f"\n총 {len(combined_df)}개 패션 상품 데이터가 'naver_fashion_products.csv'에 저장되었습니다.")
            
            # 키워드별 데이터 분석
            print("\n키워드별 패션 트렌드 분석:")
            for keyword in fashion_keywords:
                keyword_df = combined_df[combined_df['keyword'] == keyword]
                if not keyword_df.empty:
                    analysis = analyze_fashion_keywords(keyword_df)
                    
                    print(f"\n[{keyword} 분석 결과]")
                    print(f"- 수집된 상품 수: {len(keyword_df)}개")
                    print(f"- 평균 가격: {analysis['avg_price']:,.0f}원")
                    
                    print("- 주요 키워드 TOP 10:")
                    for word, count in analysis['top_keywords'][:10]:
                        print(f"  * {word}: {count}회 등장")
            
            # 전체 데이터 분석
            all_analysis = analyze_fashion_keywords(combined_df)
            
            print("\n[전체 패션 트렌드 분석 결과]")
            print(f"- 총 상품 수: {len(combined_df)}개")
            print(f"- 전체 평균 가격: {all_analysis['avg_price']:,.0f}원")
            
            print("- 인기 패션 키워드 TOP 20:")
            for word, count in all_analysis['top_keywords']:
                print(f"  * {word}: {count}회 등장")
            
        else:
            print("\n수집된 패션 상품 데이터가 없습니다.")
    
    except Exception as e:
        print(f"\n오류 발생: {e}")
    
    finally:
        # 웹드라이버 종료
        driver.quit()
    
    print("\n===== 패션 트렌드 분석 완료 =====")

if __name__ == "__main__":
    main()