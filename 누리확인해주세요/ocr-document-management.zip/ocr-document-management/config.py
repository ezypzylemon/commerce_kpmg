import os

class Config:
    # 애플리케이션 설정
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key'
    DEBUG = os.environ.get('FLASK_DEBUG') or True
    
    # 파일 업로드 설정
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'tiff', 'tif'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 최대 16MB 업로드
    
    # 데이터베이스 설정
    DATABASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ocr_documents.db')
    
    # OCR 설정
    OCR_ENGINE = 'tesseract'  # 또는 'google', 'azure' 등
