from flask import Flask, render_template, request, redirect, url_for, jsonify, session, send_from_directory
import os
import json
import uuid
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta

# OCR 처리 모듈 임포트
from ocr_processor import process_document
import db_manager as db

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev_key_for_prototype')

# 업로드 경로 설정
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
RESULT_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
ALLOWED_EXTENSIONS = {'pdf'}

# 폴더가 없으면 생성
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 제한

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 필터 적용 및 데이터 준비 헬퍼 함수
def apply_filters_to_documents(documents, filters=None):
    if not filters:
        return documents
    
    filtered_docs = documents
    
    # 문서 유형 필터
    if 'doc_type' in filters and filters['doc_type']:
        filtered_docs = [d for d in filtered_docs if d.get('document_type') == filters['doc_type']]
    
    # 브랜드 필터
    if 'brand' in filters and filters['brand']:
        filtered_docs = [d for d in filtered_docs if d.get('brand') == filters['brand']]
    
    # 검색어 필터
    if 'search' in filters and filters['search']:
        search_term = filters['search'].lower()
        filtered_docs = [d for d in filtered_docs if
                        search_term in d.get('filename', '').lower() or
                        search_term in d.get('brand', '').lower() or
                        search_term in d.get('season', '').lower()]
    
    # 날짜 범위 필터
    if 'date_from' in filters and filters['date_from']:
        date_from = datetime.strptime(filters['date_from'], '%Y-%m-%d')
        filtered_docs = [d for d in filtered_docs if 
                        'upload_date' in d and
                        datetime.strptime(d['upload_date'].split(' ')[0], '%Y-%m-%d') >= date_from]
    
    if 'date_to' in filters and filters['date_to']:
        date_to = datetime.strptime(filters['date_to'], '%Y-%m-%d')
        filtered_docs = [d for d in filtered_docs if 
                        'upload_date' in d and
                        datetime.strptime(d['upload_date'].split(' ')[0], '%Y-%m-%d') <= date_to]
    
    # 상태 필터
    if 'status' in filters and filters['status']:
        filtered_docs = [d for d in filtered_docs if d.get('status') == filters['status']]
    
    return filtered_docs

# 다국어 지원 함수
def translate(text):
    translations = {
        'complete': '완료',
        'processing': '처리 중',
        'review': '검토 필요',
        'error': '오류'
    }
    return translations.get(text, text)

# 템플릿 필터 등록
app.jinja_env.filters['trans'] = translate

@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    # 필터 매개변수 가져오기
    filters = {
        'date_from': request.args.get('date_from'),
        'date_to': request.args.get('date_to'),
        'brand': request.args.get('brand'),
        'status': request.args.get('status'),
        'search': request.args.get('search')
    }
    
    # 문서 목록 가져오기
    documents = db.get_documents()
    filtered_docs = apply_filters_to_documents(documents, filters)
    
    # 브랜드 목록 가져오기
    brands = db.get_brands()
    
    # 통계 데이터 계산
    total_documents = len(documents)
    
    # 알림 생성
    alerts = []
    for doc in documents:
        if doc.get('status') == 'review':
            alerts.append({
                'type': 'warning',
                'icon': 'exclamation-triangle',
                'title': f"{doc.get('brand', '')} 검토 필요",
                'message': f"일치율 {doc.get('match_rate', 0)}% - 검토가 필요합니다."
            })
        elif doc.get('status') == 'error':
            alerts.append({
                'type': 'error',
                'icon': 'exclamation-circle',
                'title': f"{doc.get('filename', '')} 오류",
                'message': doc.get('error_message', '처리 중 오류가 발생했습니다.')
            })
    
    # 최근 30일간 일치율 추이 데이터
    today = datetime.now()
    last_month = today - timedelta(days=30)
    
    trend_data = []
    trend_labels = []
    
    for i in range(30):
        date = last_month + timedelta(days=i)
        date_str = date.strftime('%Y-%m-%d')
        trend_labels.append(date.strftime('%m-%d'))
        
        # 해당 날짜의 문서 찾기
        day_docs = [d for d in documents if d.get('upload_date', '').startswith(date_str)]
        
        if day_docs:
            avg_match_rate = sum(d.get('match_rate', 0) for d in day_docs) / len(day_docs)
            trend_data.append(round(avg_match_rate, 1))
        else:
            # 데이터가 없는 날짜는 null 또는 이전 값 유지
            trend_data.append(trend_data[-1] if trend_data else None)
    
    stats = {
        'total_documents': total_documents,
        'total_orders': len([d for d in documents if d.get('document_type') == 'purchase_order']),
        'total_invoices': len([d for d in documents if d.get('document_type') == 'invoice']),
        'total_contracts': len([d for d in documents if d.get('document_type') == 'contract']),
        'review_needed': len([d for d in documents if d.get('status') == 'review']),
        'avg_match_rate': sum(d.get('match_rate', 0) for d in documents) / max(len(documents), 1),
        'match_percentage': sum(1 for d in documents if d.get('match_rate', 0) >= 80) / max(len(documents), 1) * 100,
        'weekly_processed': len([d for d in documents if 'upload_date' in d and 
                               (today - datetime.strptime(d['upload_date'].split(' ')[0], '%Y-%m-%d')).days <= 7]),
        'weekly_growth': 5  # 예시 값
    }
    
    return render_template('dashboard.html', 
                          documents=filtered_docs[:10],  # 최근 10개만 표시
                          stats=stats,
                          alerts=alerts[:3],  # 최신 알림 3개만 표시
                          brands=brands,
                          date_from=filters['date_from'],
                          date_to=filters['date_to'],
                          trend_data=json.dumps(trend_data),
                          trend_labels=json.dumps(trend_labels))

@app.route('/upload', methods=['GET', 'POST'])
def upload_document():
    if request.method == 'POST':
        # 파일이 첨부되었는지 확인
        if 'file' not in request.files:
            return jsonify({"error": "파일이 첨부되지 않았습니다."}), 400
        
        file = request.files['file']
        
        # 빈 파일명 확인
        if file.filename == '':
            return jsonify({"error": "선택된 파일이 없습니다."}), 400
        
        # 허용된 파일 형식 확인
        if file and allowed_file(file.filename):
            # 안전한 파일명으로 변환 및 저장
            secure_name = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            unique_filename = f"{timestamp}_{secure_name}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            
            # OCR 처리 옵션 가져오기
            options = {
                'doc_type': request.form.get('docType', '자동 감지'),
                'brand': request.form.get('brand', '자동 감지'),
                'season': request.form.get('season', ''),
                'ocr_lang': request.form.get('ocrLang', '자동 감지'),
                'enhance_tables': request.form.get('enhanceTables', 'off') == 'on',
                'extract_fields': request.form.get('extractFields', 'off') == 'on',
                'auto_compare': request.form.get('autoCompare', 'off') == 'on'
            }
            
            # OCR 처리
            try:
                result_data = process_document(file_path, options)
                
                # 결과 데이터 저장
                document_id = str(uuid.uuid4())
                document_info = {
                    'id': document_id,
                    'filename': file.filename,
                    'stored_filename': unique_filename,
                    'upload_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'document_type': result_data.get('document_type', options['doc_type']),
                    'brand': options['brand'],
                    'season': options['season'],
                    'status': 'complete',
                    'excel_filename': result_data.get('excel_filename', ''),
                    'match_rate': 100,  # 기본값, 비교 후 업데이트
                    'total_products': result_data.get('total_products', 0),
                    'data_preview': result_data.get('data_preview', [])[:5]  # 미리보기를 위한 처음 5개 항목
                }
                
                # DB에 저장
                db.save_document(document_info)
                
                return jsonify({
                    "success": True,
                    "document_id": document_id,
                    "excel_filename": result_data.get('excel_filename', ''),
                    "total_products": result_data.get('total_products', 0),
                    "data_preview": result_data.get('data_preview', [])[:5]
                })
            
            except Exception as e:
                return jsonify({"error": f"OCR 처리 중 오류가 발생했습니다: {str(e)}"}), 500
        
        return jsonify({"error": "허용되지 않은 파일 형식입니다. PDF 파일만 업로드 가능합니다."}), 400
    
    # GET 요청 처리 - 업로드 페이지 표시
    brands = db.get_brands()
    
    # OCR 처리 통계
    stats = {
        'today_processed': len([d for d in db.get_documents() if
                             d.get('upload_date', '').startswith(datetime.now().strftime('%Y-%m-%d'))]),
        'daily_target': 10,
        'today_percentage': 70,  # 예시 값
        'pending_count': len([d for d in db.get_documents() if d.get('status') == 'processing']),
        'estimated_time': '15분' if len([d for d in db.get_documents() if d.get('status') == 'processing']) > 0 else '0분'
    }
    
    # 최근 업로드 목록 (최대 5개)
    recent_uploads = sorted(
        db.get_documents(), 
        key=lambda x: datetime.strptime(x.get('upload_date', '2000-01-01 00:00:00'), '%Y-%m-%d %H:%M:%S'),
        reverse=True
    )[:5]
    
    # 현재 시간과의 차이를 계산하여 "n분 전" 형식으로 변환
    for doc in recent_uploads:
        if 'upload_date' in doc:
            upload_time = datetime.strptime(doc['upload_date'], '%Y-%m-%d %H:%M:%S')
            delta = datetime.now() - upload_time
            
            if delta.days > 0:
                doc['upload_time_ago'] = f"{delta.days}일 전"
            elif delta.seconds // 3600 > 0:
                doc['upload_time_ago'] = f"{delta.seconds // 3600}시간 전"
            elif delta.seconds // 60 > 0:
                doc['upload_time_ago'] = f"{delta.seconds // 60}분 전"
            else:
                doc['upload_time_ago'] = "방금 전"
    
    return render_template('upload.html', brands=brands, stats=stats, recent_uploads=recent_uploads)

@app.route('/orders')
def orders():
    # 필터 매개변수 가져오기
    filters = {
        'doc_type': request.args.get('type'),
        'brand': request.args.get('brand'),
        'search': request.args.get('search')
    }
    
    # 모든 문서 데이터 가져오기
    documents = db.get_documents()
    filtered_docs = apply_filters_to_documents(documents, filters)
    
    # URL 매개변수로 전달된 문서 ID 확인
    doc_id = request.args.get('doc')
    selected_doc = None
    
    if doc_id:
        for doc in documents:
            if doc['id'] == doc_id:
                selected_doc = doc
                break
    
    return render_template('orders.html', documents=filtered_docs, selected_doc=selected_doc, brands=db.get_brands())

@app.route('/reports')
def reports():
    # 모든 문서 데이터 가져오기
    documents = db.get_documents()
    
    # 브랜드별 데이터 집계
    brands = {}
    for doc in documents:
        brand = doc.get('brand', '미분류')
        if brand not in brands:
            brands[brand] = {
                'count': 0,
                'amount': 0
            }
        brands[brand]['count'] += 1
        # 금액이 있으면 합산
        amount = 0
        try:
            if 'amount' in doc:
                amount_str = doc['amount']
                # 통화 기호와 쉼표 제거
                amount_str = amount_str.replace('₩', '').replace(',', '')
                amount = float(amount_str)
        except (ValueError, TypeError):
            pass
        brands[brand]['amount'] += amount
    
    # 시즌별 데이터 집계
    seasons = {}
    for doc in documents:
        season = doc.get('season', '미분류')
        if season not in seasons:
            seasons[season] = {
                'count': 0,
                'amount': 0
            }
        seasons[season]['count'] += 1
        # 금액이 있으면 합산
        amount = 0
        try:
            if 'amount' in doc:
                amount_str = doc['amount']
                # 통화 기호와 쉼표 제거
                amount_str = amount_str.replace('₩', '').replace(',', '')
                amount = float(amount_str)
        except (ValueError, TypeError):
            pass
        seasons[season]['amount'] += amount
    
    return render_template('reports.html', documents=documents, brands=brands, seasons=seasons)

@app.route('/inventory')
def inventory():
    # 모든 문서 데이터 가져오기
    documents = db.get_documents()
    
    # 입고 현황 계산 (실제로는 더 복잡한 로직이 필요)
    inventory_status = {
        'completed': len([d for d in documents if d.get('status') == 'complete']),
        'in_progress': len([d for d in documents if d.get('status') == 'processing']),
        'review': len([d for d in documents if d.get('status') == 'review'])
    }
    
    return render_template('inventory.html', documents=documents, inventory_status=inventory_status)

@app.route('/calendar')
def calendar():
    # 모든 문서 데이터 가져오기
    documents = db.get_documents()
    
    # 날짜별 이벤트 준비
    events = {}
    for doc in documents:
        date = doc.get('upload_date', '').split(' ')[0]  # 날짜 부분만 추출
        if date:
            if date not in events:
                events[date] = []
            events[date].append({
                'id': doc['id'],
                'title': doc['filename'],
                'type': doc.get('document_type', '문서')
            })
    
    return render_template('calendar.html', documents=documents, events=events)

@app.route('/api/documents', methods=['GET'])
def get_documents():
    """문서 목록 API 엔드포인트"""
    documents = db.get_documents()
    
    # 필터링 매개변수
    filters = {
        'doc_type': request.args.get('type'),
        'brand': request.args.get('brand'),
        'search': request.args.get('search'),
        'date_from': request.args.get('date_from'),
        'date_to': request.args.get('date_to'),
        'status': request.args.get('status')
    }
    
    filtered_docs = apply_filters_to_documents(documents, filters)
    
    # 개수 제한
    limit = request.args.get('limit')
    if limit and limit.isdigit():
        filtered_docs = filtered_docs[:int(limit)]
    
    return jsonify(filtered_docs)

@app.route('/api/documents/<doc_id>', methods=['GET'])
def get_document(doc_id):
    """특정 문서 정보 API 엔드포인트"""
    document = db.get_document(doc_id)
    
    if document:
        return jsonify(document)
    
    return jsonify({"error": "문서를 찾을 수 없습니다."}), 404

@app.route('/api/documents/<doc_id>', methods=['DELETE'])
def delete_document(doc_id):
    """문서 삭제 API 엔드포인트"""
    result = db.delete_document(doc_id)
    
    if result:
        return jsonify({"success": True})
    
    return jsonify({"error": "문서 삭제에 실패했습니다."}), 500

@app.route('/api/documents/compare', methods=['POST'])
def compare_documents():
    """문서 비교 API 엔드포인트"""
    data = request.json
    doc1_id = data.get('document1_id')
    doc2_id = data.get('document2_id')
    
    if not doc1_id or not doc2_id:
        return jsonify({"error": "두 문서의 ID가 필요합니다."}), 400
    
    doc1 = db.get_document(doc1_id)
    doc2 = db.get_document(doc2_id)
    
    if not doc1 or not doc2:
        return jsonify({"error": "하나 이상의 문서를 찾을 수 없습니다."}), 404
    
    # 비교 로직 (실제로는 더 복잡할 수 있음)
    # 여기서는 단순한 예시만 제공
    
    # 일치 항목과 불일치 항목 찾기
    matches = []
    mismatches = []
    
    # 제품 정보 비교 (있다면)
    products1 = doc1.get('data_preview', [])
    products2 = doc2.get('data_preview', [])
    
    # 모든 제품 코드 모음
    all_products = set()
    for product in products1:
        if 'product_code' in product or '모델코드' in product:
            key = 'product_code' if 'product_code' in product else '모델코드'
            all_products.add(product[key])
    
    for product in products2:
        if 'product_code' in product or '모델코드' in product:
            key = 'product_code' if 'product_code' in product else '모델코드'
            all_products.add(product[key])
    
    # 제품별 비교
    total_items = len(all_products)
    matched_items = 0
    
    for product_code in all_products:
        # doc1에서 제품 찾기
        product1 = None
        for p in products1:
            if ('product_code' in p and p['product_code'] == product_code) or \
               ('모델코드' in p and p['모델코드'] == product_code):
                product1 = p
                break
        
        # doc2에서 제품 찾기
        product2 = None
        for p in products2:
            if ('product_code' in p and p['product_code'] == product_code) or \
               ('모델코드' in p and p['모델코드'] == product_code):
                product2 = p
                break
        
        if not product1 or not product2:
            # 한쪽에만 있는 항목
            mismatches.append({
                'product_code': product_code,
                'exists_in_doc1': bool(product1),
                'exists_in_doc2': bool(product2),
                'reason': '한쪽 문서에만 존재'
            })
            continue
        
        # 필드 비교
        mismatched_fields = []
        fields_to_compare = [
            ('quantity', 'quantity', '수량'),
            ('quantity', '총_수량', '수량'),
            ('price', 'price', '가격'),
            ('price', '구매가', '가격'),
            ('color', 'color', '색상'),
            ('color', '컬러', '색상'),
        ]
        
        for field1, field2, display_name in fields_to_compare:
            if (field1 in product1 or field2 in product1) and (field1 in product2 or field2 in product2):
                value1 = product1.get(field1, product1.get(field2))
                value2 = product2.get(field1, product2.get(field2))
                
                if str(value1) != str(value2):
                    mismatched_fields.append({
                        'field': display_name,
                        'value1': value1,
                        'value2': value2
                    })
        
        if mismatched_fields:
            mismatches.append({
                'product_code': product_code,
                'exists_in_doc1': True,
                'exists_in_doc2': True,
                'mismatched_fields': mismatched_fields
            })
        else:
            matched_items += 1
            product_name = product1.get('name', product1.get('모델명', product_code))
            matches.append({
                'product_code': product_code,
                'name': product_name,
                'quantity': product1.get('quantity', product1.get('총_수량', ''))
            })
    
    # 일치율 계산
    match_percentage = 0
    if total_items > 0:
        match_percentage = int(matched_items / total_items * 100)
    
    # 결과 구성
    result = {
        'matches': matches,
        'mismatches': mismatches,
        'summary': {
            'total_items': total_items,
            'matched_items': matched_items,
            'mismatched_items': total_items - matched_items,
            'match_percentage': match_percentage
        }
    }
    
    # 첫 번째 문서의 일치율 업데이트
    doc1['match_rate'] = match_percentage
    db.save_document(doc1)
    
    return jsonify({"result": result})

@app.route('/download/<path:filename>', methods=['GET'])
def download_file(filename):
    """파일 다운로드 API 엔드포인트"""
    return send_from_directory(app.config['RESULT_FOLDER'], filename)

@app.route('/api/documents/<doc_id>/match-rate', methods=['PUT'])
def update_match_rate(doc_id):
    """문서 일치율 업데이트 API 엔드포인트"""
    data = request.json
    match_rate = data.get('match_rate')
    
    if match_rate is None:
        return jsonify({"error": "일치율이 전달되지 않았습니다."}), 400
    
    document = db.get_document(doc_id)
    
    if document:
        document['match_rate'] = match_rate
        db.save_document(document)
        return jsonify({"success": True})
    
    return jsonify({"error": "문서를 찾을 수 없습니다."}), 404

@app.route('/api/brands', methods=['GET'])
def get_brands():
    """브랜드 목록 API 엔드포인트"""
    brands = db.get_brands()
    return jsonify(brands)

@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """통계 정보 API 엔드포인트"""
    stats = db.get_statistics()
    return jsonify(stats)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error_code=404, error_message='요청하신 페이지를 찾을 수 없습니다.'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('error.html', error_code=500, error_message='서버에 문제가 발생했습니다.'), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)from flask import Flask, render_template, request, redirect, url_for, jsonify, session, send_from_directory
import os
import json
import uuid
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta

# OCR 처리 모듈 임포트
from ocr_processor import process_document
import db_manager as db

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev_key_for_prototype')

# 업로드 경로 설정
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
RESULT_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
ALLOWED_EXTENSIONS = {'pdf'}

# 폴더가 없으면 생성
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 제한

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 필터from flask import Flask, render_template, request, redirect, url_for, jsonify, session, send_from_directory
import os
import json
import uuid
from werkzeug.utils import secure_filename
from datetime import datetime

# OCR 처리 모듈 임포트
from ocr_processor import process_document

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev_key_for_prototype')

# 업로드 경로 설정
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
RESULT_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
ALLOWED_EXTENSIONS = {'pdf'}

# 폴더가 없으면 생성
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 제한

# DB 대신 간단한 파일 기반 데이터 저장
DOCUMENTS_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'documents.json')
os.makedirs(os.path.dirname(DOCUMENTS_DB), exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_documents():
    """문서 데이터베이스 로드"""
    if os.path.exists(DOCUMENTS_DB):
        with open(DOCUMENTS_DB, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def save_documents(documents):
    """문서 데이터베이스 저장"""
    with open(DOCUMENTS_DB, 'w', encoding='utf-8') as f:
        json.dump(documents, f, ensure_ascii=False, indent=2)

def save_document_info(doc_info):
    """새로운 문서 정보 저장"""
    documents = load_documents()
    # document_id가 이미 있으면 업데이트, 없으면 추가
    for i, doc in enumerate(documents):
        if doc['id'] == doc_info['id']:
            documents[i] = doc_info
            save_documents(documents)
            return doc_info
    
    # 새 문서 추가
    documents.append(doc_info)
    save_documents(documents)
    return doc_info

@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    # 최근 문서 목록 가져오기
    documents = load_documents()
    
    # 통계 데이터 계산
    stats = {
        'total_documents': len(documents),
        'total_orders': len([d for d in documents if d.get('document_type') == 'purchase_order']),
        'total_invoices': len([d for d in documents if d.get('document_type') == 'invoice']),
        'total_contracts': len([d for d in documents if d.get('document_type') == 'contract']),
        'review_needed': len([d for d in documents if d.get('status') == 'review']),
        'avg_match_rate': sum([d.get('match_rate', 0) for d in documents]) / max(len(documents), 1)
    }
    
    return render_template('dashboard.html', documents=documents, stats=stats)

@app.route('/upload', methods=['GET', 'POST'])
def upload_document():
    if request.method == 'POST':
        # 파일이 첨부되었는지 확인
        if 'file' not in request.files:
            return jsonify({"error": "파일이 첨부되지 않았습니다."}), 400
        
        file = request.files['file']
        
        # 빈 파일명 확인
        if file.filename == '':
            return jsonify({"error": "선택된 파일이 없습니다."}), 400
        
        # 허용된 파일 형식 확인
        if file and allowed_file(file.filename):
            # 안전한 파일명으로 변환 및 저장
            secure_name = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            unique_filename = f"{timestamp}_{secure_name}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            
            # OCR 처리 옵션 가져오기
            options = {
                'doc_type': request.form.get('docType', '자동 감지'),
                'brand': request.form.get('brand', '자동 감지'),
                'season': request.form.get('season', ''),
                'ocr_lang': request.form.get('ocrLang', '자동 감지'),
                'enhance_tables': request.form.get('enhanceTables', 'off') == 'on',
                'extract_fields': request.form.get('extractFields', 'off') == 'on',
                'auto_compare': request.form.get('autoCompare', 'off') == 'on'
            }
            
            # OCR 처리 (비동기 처리 가능)
            try:
                result_data = process_document(file_path, options)
                
                # 결과 데이터 저장
                document_id = str(uuid.uuid4())
                document_info = {
                    'id': document_id,
                    'filename': file.filename,
                    'stored_filename': unique_filename,
                    'upload_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'document_type': options['doc_type'],
                    'brand': options['brand'],
                    'season': options['season'],
                    'status': 'complete',
                    'excel_filename': result_data.get('excel_filename', ''),
                    'match_rate': 100,  # 기본값, 비교 후 업데이트
                    'total_products': result_data.get('total_products', 0),
                    'data_preview': result_data.get('data_preview', [])[:5]  # 미리보기를 위한 처음 5개 항목
                }
                
                # DB에 저장
                save_document_info(document_info)
                
                return jsonify({
                    "success": True,
                    "document_id": document_id,
                    "excel_filename": result_data.get('excel_filename', ''),
                    "total_products": result_data.get('total_products', 0),
                    "data_preview": result_data.get('data_preview', [])[:5]
                })
            
            except Exception as e:
                return jsonify({"error": f"OCR 처리 중 오류가 발생했습니다: {str(e)}"}), 500
        
        return jsonify({"error": "허용되지 않은 파일 형식입니다. PDF 파일만 업로드 가능합니다."}), 400
    
    # GET 요청 처리 - 업로드 페이지 표시
    return render_template('upload.html')

@app.route('/orders')
def orders():
    # 모든 문서 데이터 가져오기
    documents = load_documents()
    
    # URL 매개변수로 전달된 문서 ID 확인
    doc_id = request.args.get('doc')
    selected_doc = None
    
    if doc_id:
        for doc in documents:
            if doc['id'] == doc_id:
                selected_doc = doc
                break
    
    return render_template('orders.html', documents=documents, selected_doc=selected_doc)

@app.route('/reports')
def reports():
    # 모든 문서 데이터 가져오기
    documents = load_documents()
    
    # 브랜드별 데이터 집계
    brands = {}
    for doc in documents:
        brand = doc.get('brand', '미분류')
        if brand not in brands:
            brands[brand] = {
                'count': 0,
                'amount': 0
            }
        brands[brand]['count'] += 1
        brands[brand]['amount'] += float(doc.get('amount', 0))
    
    # 시즌별 데이터 집계
    seasons = {}
    for doc in documents:
        season = doc.get('season', '미분류')
        if season not in seasons:
            seasons[season] = {
                'count': 0,
                'amount': 0
            }
        seasons[season]['count'] += 1
        seasons[season]['amount'] += float(doc.get('amount', 0))
    
    return render_template('reports.html', documents=documents, brands=brands, seasons=seasons)

@app.route('/inventory')
def inventory():
    # 모든 문서 데이터 가져오기
    documents = load_documents()
    
    # 입고 현황 계산 (실제로는 더 복잡한 로직이 필요)
    inventory_status = {
        'completed': len([d for d in documents if d.get('status') == 'complete']),
        'in_progress': len([d for d in documents if d.get('status') == 'processing']),
        'review': len([d for d in documents if d.get('status') == 'review'])
    }
    
    return render_template('inventory.html', documents=documents, inventory_status=inventory_status)

@app.route('/calendar')
def calendar():
    # 모든 문서 데이터 가져오기
    documents = load_documents()
    
    # 날짜별 이벤트 준비
    events = {}
    for doc in documents:
        date = doc.get('upload_date', '').split(' ')[0]  # 날짜 부분만 추출
        if date:
            if date not in events:
                events[date] = []
            events[date].append({
                'id': doc['id'],
                'title': doc['filename'],
                'type': doc.get('document_type', '문서')
            })
    
    return render_template('calendar.html', documents=documents, events=events)

@app.route('/api/documents', methods=['GET'])
def get_documents():
    """문서 목록 API 엔드포인트"""
    documents = load_documents()
    
    # 필터링 매개변수
    doc_type = request.args.get('type')
    brand = request.args.get('brand')
    search = request.args.get('search')
    
    # 필터 적용
    if doc_type:
        documents = [d for d in documents if d.get('document_type') == doc_type]
    
    if brand:
        documents = [d for d in documents if d.get('brand') == brand]
    
    if search:
        search = search.lower()
        documents = [d for d in documents if search in d.get('filename', '').lower() or 
                     search in d.get('brand', '').lower()]
    
    return jsonify(documents)

@app.route('/api/documents/<doc_id>', methods=['GET'])
def get_document(doc_id):
    """특정 문서 정보 API 엔드포인트"""
    documents = load_documents()
    
    for doc in documents:
        if doc['id'] == doc_id:
            return jsonify(doc)
    
    return jsonify({"error": "문서를 찾을 수 없습니다."}), 404

@app.route('/api/documents/compare', methods=['POST'])
def compare_documents():
    """문서 비교 API 엔드포인트"""
    data = request.json
    doc1_id = data.get('document1_id')
    doc2_id = data.get('document2_id')
    
    if not doc1_id or not doc2_id:
        return jsonify({"error": "두 문서의 ID가 필요합니다."}), 400
    
    documents = load_documents()
    doc1 = None
    doc2 = None
    
    for doc in documents:
        if doc['id'] == doc1_id:
            doc1 = doc
        if doc['id'] == doc2_id:
            doc2 = doc
    
    if not doc1 or not doc2:
        return jsonify({"error": "하나 이상의 문서를 찾을 수 없습니다."}), 404
    
    # 비교 로직 (실제로는 더 복잡할 수 있음)
    # 여기서는 단순한 예시만 제공
    
    # 일치 항목과 불일치 항목 찾기
    matches = []
    mismatches = []
    
    # 제품 정보 비교 (있다면)
    products1 = doc1.get('data_preview', [])
    products2 = doc2.get('data_preview', [])
    
    # 모든 제품 코드 모음
    all_products = set()
    for product in products1:
        if 'product_code' in product:
            all_products.add(product['product_code'])
    
    for product in products2:
        if 'product_code' in product:
            all_products.add(product['product_code'])
    
    # 제품별 비교
    total_items = len(all_products)
    matched_items = 0
    
    for product_code in all_products:
        product1 = next((p for p in products1 if p.get('product_code') == product_code), None)
        product2 = next((p for p in products2 if p.get('product_code') == product_code), None)
        
        if not product1 or not product2:
            # 한쪽에만 있는 항목
            mismatches.append({
                'product_code': product_code,
                'exists_in_doc1': bool(product1),
                'exists_in_doc2': bool(product2),
                'reason': '한쪽 문서에만 존재'
            })
            continue
        
        # 필드 비교
        mismatched_fields = []
        
        for field in ['quantity', 'price', 'color', 'size']:
            if field in product1 and field in product2:
                if str(product1[field]) != str(product2[field]):
                    mismatched_fields.append({
                        'field': field,
                        'value1': product1[field],
                        'value2': product2[field]
                    })
        
        if mismatched_fields:
            mismatches.append({
                'product_code': product_code,
                'exists_in_doc1': True,
                'exists_in_doc2': True,
                'mismatched_fields': mismatched_fields
            })
        else:
            matched_items += 1
            matches.append({
                'product_code': product_code,
                'name': product1.get('name', ''),
                'quantity': product1.get('quantity', '')
            })
    
    # 일치율 계산
    match_percentage = 0
    if total_items > 0:
        match_percentage = int(matched_items / total_items * 100)
    
    # 결과 구성
    result = {
        'matches': matches,
        'mismatches': mismatches,
        'summary': {
            'total_items': total_items,
            'matched_items': matched_items,
            'mismatched_items': total_items - matched_items,
            'match_percentage': match_percentage
        }
    }
    
    # 첫 번째 문서의 일치율 업데이트
    for i, doc in enumerate(documents):
        if doc['id'] == doc1_id:
            documents[i]['match_rate'] = match_percentage
            save_documents(documents)
            break
    
    return jsonify({"result": result})

@app.route('/download/<path:filename>', methods=['GET'])
def download_file(filename):
    """파일 다운로드 API 엔드포인트"""
    return send_from_directory(app.config['RESULT_FOLDER'], filename)

@app.route('/api/documents/<doc_id>/match-rate', methods=['PUT'])
def update_match_rate(doc_id):
    """문서 일치율 업데이트 API 엔드포인트"""
    data = request.json
    match_rate = data.get('match_rate')
    
    if match_rate is None:
        return jsonify({"error": "일치율이 전달되지 않았습니다."}), 400
    
    documents = load_documents()
    
    for i, doc in enumerate(documents):
        if doc['id'] == doc_id:
            documents[i]['match_rate'] = match_rate
            save_documents(documents)
            return jsonify({"success": True})
    
    return jsonify({"error": "문서를 찾을 수 없습니다."}), 404

if __name__ == '__main__':
    app.run(debug=True, port=5000)