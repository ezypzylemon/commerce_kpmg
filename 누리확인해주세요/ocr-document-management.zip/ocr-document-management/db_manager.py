import os
import json
from datetime import datetime

# 데이터 파일 경로
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'db')
DOCUMENTS_FILE = os.path.join(DATA_DIR, 'documents.json')
BRANDS_FILE = os.path.join(DATA_DIR, 'brands.json')
USERS_FILE = os.path.join(DATA_DIR, 'users.json')

# 디렉토리 생성
os.makedirs(DATA_DIR, exist_ok=True)

def load_data(file_path, default_data=None):
    """
    JSON 파일에서 데이터를 로드합니다.
    파일이 없으면 기본 데이터 또는 빈 리스트를 반환합니다.
    """
    if default_data is None:
        default_data = []
    
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"[ERROR] 데이터 로드 중 오류: {str(e)}")
            return default_data
    return default_data

def save_data(file_path, data):
    """
    데이터를 JSON 파일로 저장합니다.
    """
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except IOError as e:
        print(f"[ERROR] 데이터 저장 중 오류: {str(e)}")
        return False

# 문서 관련 함수
def get_documents():
    """
    모든 문서를 가져옵니다.
    """
    return load_data(DOCUMENTS_FILE)

def get_document(document_id):
    """
    ID로 문서를 찾습니다.
    """
    documents = get_documents()
    for doc in documents:
        if doc.get('id') == document_id:
            return doc
    return None

def save_document(document):
    """
    문서를 저장합니다. ID가 있으면 업데이트, 없으면 신규 추가합니다.
    """
    documents = get_documents()
    
    # ID가 있는지 확인
    if 'id' in document:
        # 기존 문서 업데이트
        for i, doc in enumerate(documents):
            if doc.get('id') == document['id']:
                documents[i] = document
                return save_data(DOCUMENTS_FILE, documents)
    else:
        # 신규 문서 ID 생성
        document['id'] = str(len(documents) + 1)
        document['created_at'] = datetime.now().isoformat()
    
    # 신규 문서 추가
    documents.append(document)
    return save_data(DOCUMENTS_FILE, documents)

def delete_document(document_id):
    """
    ID로 문서를 삭제합니다.
    """
    documents = get_documents()
    documents = [doc for doc in documents if doc.get('id') != document_id]
    return save_data(DOCUMENTS_FILE, documents)

# 브랜드 관련 함수
def get_brands():
    """
    모든 브랜드를 가져옵니다.
    """
    return load_data(BRANDS_FILE, [
        {"id": "1", "name": "TOGA VIRILIS", "code": "TOGA"},
        {"id": "2", "name": "WILD DONKEY", "code": "WILD"},
        {"id": "3", "name": "ATHLETICS FTWR", "code": "ATHL"},
        {"id": "4", "name": "BASERANGE", "code": "BASE"},
        {"id": "5", "name": "NOU NOU", "code": "NONOU"}
    ])

def save_brand(brand):
    """
    브랜드를 저장합니다.
    """
    brands = get_brands()
    
    # ID가 있는지 확인
    if 'id' in brand:
        # 기존 브랜드 업데이트
        for i, b in enumerate(brands):
            if b.get('id') == brand['id']:
                brands[i] = brand
                return save_data(BRANDS_FILE, brands)
    else:
        # 신규 브랜드 ID 생성
        brand['id'] = str(len(brands) + 1)
    
    # 신규 브랜드 추가
    brands.append(brand)
    return save_data(BRANDS_FILE, brands)

# 사용자 관련 함수
def get_users():
    """
    모든 사용자를 가져옵니다.
    """
    return load_data(USERS_FILE, [
        {
            "id": "1",
            "username": "admin",
            "password": "admin123",  # 실제로는 해시 처리되어야 합니다
            "name": "관리자",
            "role": "admin"
        }
    ])

def get_user(username, password):
    """
    사용자명과 비밀번호로 사용자를 찾습니다.
    """
    users = get_users()
    for user in users:
        if user.get('username') == username and user.get('password') == password:
            return user
    return None

# 통계 관련 함수
def get_statistics():
    """
    문서 통계 정보를 가져옵니다.
    """
    documents = get_documents()
    
    stats = {
        'total_documents': len(documents),
        'by_type': {},
        'by_brand': {},
        'by_month': {},
        'recent_documents': sorted(documents, key=lambda x: x.get('created_at', ''), reverse=True)[:5]
    }
    
    # 유형별 통계
    for doc in documents:
        doc_type = doc.get('document_type', 'unknown')
        if doc_type not in stats['by_type']:
            stats['by_type'][doc_type] = 0
        stats['by_type'][doc_type] += 1
        
        # 브랜드별 통계
        brand = doc.get('brand', 'unknown')
        if brand not in stats['by_brand']:
            stats['by_brand'][brand] = 0
        stats['by_brand'][brand] += 1
        
        # 월별 통계
        created_at = doc.get('created_at', '')
        if created_at:
            try:
                date = datetime.fromisoformat(created_at)
                month_key = date.strftime('%Y-%m')
                if month_key not in stats['by_month']:
                    stats['by_month'][month_key] = 0
                stats['by_month'][month_key] += 1
            except ValueError:
                pass
    
    return stats

# 기존 데이터 유효성 검사
def validate_data():
    """
    기존 데이터 파일의 유효성을 검사하고 필요시 초기화합니다.
    """
    # 문서 데이터 확인
    documents = load_data(DOCUMENTS_FILE)
    if not isinstance(documents, list):
        print("[WARN] 문서 데이터 형식이 잘못되었습니다. 초기화합니다.")
        save_data(DOCUMENTS_FILE, [])
    
    # 브랜드 데이터 확인
    brands = load_data(BRANDS_FILE)
    if not isinstance(brands, list):
        print("[WARN] 브랜드 데이터 형식이 잘못되었습니다. 초기화합니다.")
        default_brands = [
            {"id": "1", "name": "TOGA VIRILIS", "code": "TOGA"},
            {"id": "2", "name": "WILD DONKEY", "code": "WILD"},
            {"id": "3", "name": "ATHLETICS FTWR", "code": "ATHL"},
            {"id": "4", "name": "BASERANGE", "code": "BASE"},
            {"id": "5", "name": "NOU NOU", "code": "NONOU"}
        ]
        save_data(BRANDS_FILE, default_brands)
    
    # 사용자 데이터 확인
    users = load_data(USERS_FILE)
    if not isinstance(users, list):
        print("[WARN] 사용자 데이터 형식이 잘못되었습니다. 초기화합니다.")
        default_users = [
            {
                "id": "1",
                "username": "admin",
                "password": "admin123",
                "name": "관리자",
                "role": "admin"
            }
        ]
        save_data(USERS_FILE, default_users)

# 초기화 실행
validate_data()