import os
import tempfile
import pandas as pd
import re
import cv2
import numpy as np
import json
from pdf2image import convert_from_path
from google.cloud import vision
from datetime import datetime
import traceback

# Vision 클라이언트 초기화 - 환경 변수에 이미 설정되어 있다고 가정
try:
    vision_client = vision.ImageAnnotatorClient()
    print("[INFO] Google Cloud Vision API 클라이언트가 초기화되었습니다.")
except Exception as e:
    print(f"[ERROR] Google Cloud Vision API 클라이언트 초기화 실패: {str(e)}")
    print("[INFO] 테스트 모드로 실행합니다. 실제 OCR 대신 샘플 데이터를 반환합니다.")
    vision_client = None

def process_document(file_path, options=None):
    """
    문서 처리 메인 함수 - 문서 유형에 따라 적절한 처리 함수 호출
    
    Args:
        file_path: 업로드된 PDF 파일 경로
        options: 처리 옵션 딕셔너리
            - doc_type: 문서 유형 ('자동 감지', 'invoice', 'purchase_order', 'contract')
            - brand: 브랜드명 ('자동 감지', 'TOGA VIRILIS', 'WILD DONKEY', 등)
            - season: 시즌 ('2024SS', '2024FW', 등)
            - ocr_lang: OCR 언어 ('자동 감지', '한국어', '영어', 등)
            - enhance_tables: 표 인식 향상 (True/False)
            - extract_fields: 주요 필드 자동 추출 (True/False)
            - auto_compare: 기존 문서와 자동 비교 (True/False)
    
    Returns:
        처리 결과 딕셔너리 (엑셀 파일명, 전체 제품 수, 미리보기 데이터 등)
    """
    # 기본 옵션 설정
    if options is None:
        options = {
            'doc_type': '자동 감지',
            'brand': '자동 감지',
            'season': '',
            'ocr_lang': '자동 감지',
            'enhance_tables': True,
            'extract_fields': True,
            'auto_compare': False
        }
    
    # 결과 저장 폴더 생성
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    result_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results', timestamp)
    os.makedirs(result_folder, exist_ok=True)
    
    try:
        # Vision API 클라이언트가 없으면 테스트 모드 실행
        if vision_client is None:
            return generate_test_data(options, result_folder, timestamp)
        
        # PDF를 이미지로 변환
        image_paths = pdf_to_image(file_path, result_folder)
        
        if not image_paths:
            raise Exception("PDF를 이미지로 변환하는 데 실패했습니다.")
        
        # 문서 유형 감지 (옵션이 '자동 감지'인 경우)
        doc_type = options['doc_type']
        if doc_type == '자동 감지':
            doc_type = detect_document_type(image_paths[0])
            print(f"[INFO] 감지된 문서 유형: {doc_type}")
        
        # 문서 유형에 따라 적절한 처리 함수 호출
        if doc_type == 'invoice':
            result = process_invoice(image_paths, options, result_folder)
        elif doc_type in ['purchase_order', '발주서']:
            result = process_purchase_order(image_paths, options, result_folder)
        elif doc_type in ['contract', '계약서']:
            result = process_contract(image_paths, options, result_folder)
        else:
            # 기본적으로 일반 문서 처리
            result = process_general_document(image_paths, options, result_folder)
        
        # 공통 메타데이터 추가
        result['document_type'] = doc_type
        result['timestamp'] = timestamp
        result['result_folder'] = result_folder
        
        return result
    
    except Exception as e:
        print(f"[ERROR] 문서 처리 중 오류 발생: {str(e)}")
        print(traceback.format_exc())
        
        # 오류 정보 저장
        error_log_path = os.path.join(result_folder, "error_log.txt")
        with open(error_log_path, 'w', encoding='utf-8') as f:
            f.write(f"처리 중 오류 발생: {str(e)}\n")
            f.write(traceback.format_exc())
        
        # 오류 발생 시에도 기본 정보 반환
        return {
            'error': str(e),
            'document_type': options['doc_type'],
            'timestamp': timestamp,
            'result_folder': result_folder,
            'excel_filename': 'error_log.txt',
            'total_products': 0,
            'data_preview': []
        }

def pdf_to_image(pdf_path, output_folder, dpi=300):
    """PDF를 이미지로 변환합니다."""
    try:
        # 첫 번째 페이지만 변환
        images = convert_from_path(pdf_path, dpi=dpi, first_page=1, last_page=1)
        image_paths = []
        
        for i, image in enumerate(images):
            output_path = os.path.join(output_folder, f"page_{i+1}.jpg")
            image.save(output_path, 'JPEG')
            image_paths.append(output_path)
        
        return image_paths
    except Exception as e:
        print(f"[ERROR] PDF 변환 중 오류 발생: {str(e)}")
        return []

def detect_document_type(image_path):
    """이미지 기반으로 문서 유형을 감지합니다."""
    try:
        # 이미지 파일 읽기
        with open(image_path, 'rb') as image_file:
            content = image_file.read()
        
        vision_image = vision.Image(content=content)
        
        # 텍스트 감지 요청
        response = vision_client.text_detection(image=vision_image)
        
        if response.error.message:
            print(f"Error: {response.error.message}")
            return "unknown"
        
        # 텍스트 추출
        text = response.text_annotations[0].description.lower() if response.text_annotations else ""
        
        # 문서 유형 판별을 위한 키워드
        invoice_keywords = ['invoice', 'bill', 'tax', 'payment', '인보이스']
        purchase_order_keywords = ['purchase order', 'p.o', 'po#', '발주서', '주문서']
        contract_keywords = ['contract', 'agreement', '계약', '계약서']
        
        # 키워드 검색으로 문서 유형 판별
        for keyword in invoice_keywords:
            if keyword in text:
                return 'invoice'
        
        for keyword in purchase_order_keywords:
            if keyword in text:
                return 'purchase_order'
        
        for keyword in contract_keywords:
            if keyword in text:
                return 'contract'
        
        # 기본값
        return 'unknown'
    
    except Exception as e:
        print(f"[ERROR] 문서 유형 감지 중 오류 발생: {str(e)}")
        return 'unknown'

def extract_text_with_reading_order(image_path):
    """
    Google Cloud Vision API의 document_text_detection을 사용하여
    읽기 순서를 보존한 텍스트를 추출하는 함수
    """
    try:
        # 이미지 파일 읽기
        with open(image_path, 'rb') as image_file:
            content = image_file.read()
        
        vision_image = vision.Image(content=content)
        
        # 문서 텍스트 감지 요청 (위치 정보 포함)
        response = vision_client.document_text_detection(image=vision_image)
        
        # 오류 처리
        if response.error.message:
            print(f"Error: {response.error.message}")
            return ""
        
        # 단어들을 읽기 순서대로 정렬하기 위한 리스트
        ordered_text = []
        
        # 페이지별 처리
        for page in response.full_text_annotation.pages:
            # 각 블록마다
            for block in page.blocks:
                for paragraph in block.paragraphs:
                    # 단락 내의 모든 단어 추적
                    para_words = []
                    
                    for word in paragraph.words:
                        word_text = ''.join([symbol.text for symbol in word.symbols])
                        # 단어의 상단 좌측 좌표
                        y_coord = word.bounding_box.vertices[0].y
                        x_coord = word.bounding_box.vertices[0].x
                        para_words.append((y_coord, x_coord, word_text))
                    
                    # 단락 내에서 단어를 위치에 따라 정렬
                    para_words.sort(key=lambda x: (x[0], x[1]))
                    ordered_text.extend(para_words)
        
        # y좌표로 먼저 정렬 (행), 그다음 x좌표로 정렬 (열)
        ordered_text.sort(key=lambda x: (x[0], x[1]))
        
        # 같은 행에 있는 단어들을 그룹화
        current_line = []
        result_lines = []
        current_y = ordered_text[0][0] if ordered_text else 0
        y_threshold = 10  # 같은 행으로 간주할 y좌표 차이 임계값
        
        for y, x, text in ordered_text:
            if abs(y - current_y) > y_threshold:
                # 새 행 시작, 현재 행 저장하고 초기화
                if current_line:
                    # x좌표로 정렬하여 한 행 내에서 왼쪽에서 오른쪽으로 단어 순서 유지
                    result_lines.append(' '.join([word for _, _, word in sorted(current_line, key=lambda item: item[1])]))
                current_line = [(y, x, text)]
                current_y = y
            else:
                current_line.append((y, x, text))
        
        # 마지막 행 처리
        if current_line:
            result_lines.append(' '.join([word for _, _, word in sorted(current_line, key=lambda item: item[1])]))
        
        # 연속된 빈 줄을 제거하고 줄 앞뒤 공백 제거
        processed_lines = []
        prev_line_empty = False
        
        for line in result_lines:
            line = line.strip()
            is_empty = len(line) == 0
            
            if not (is_empty and prev_line_empty):
                processed_lines.append(line)
            
            prev_line_empty = is_empty
        
        result_text = '\n'.join(processed_lines)
        
        return result_text
    
    except Exception as e:
        print(f"[ERROR] 텍스트 추출 중 오류 발생: {str(e)}")
        print(traceback.format_exc())
        return ""

def process_invoice(image_paths, options, result_folder):
    """인보이스 문서 처리 함수"""
    result = {
        'excel_filename': '',
        'total_products': 0,
        'data_preview': []
    }
    
    try:
        # 첫 번째 페이지만 처리
        image_path = image_paths[0]
        
        # 전체 텍스트 추출
        full_text = extract_text_with_reading_order(image_path)
        
        # 텍스트 저장
        text_path = os.path.join(result_folder, "extracted_text.txt")
        with open(text_path, 'w', encoding='utf-8') as f:
            f.write(full_text)
        
        # 이미지 로드
        image = cv2.imread(image_path)
        
        # 메타데이터 추출 (브랜드, 시즌 등)
        metadata = extract_metadata(image, full_text)
        
        # 테이블 감지 및 데이터 추출
        product_sections = detect_product_sections(image, full_text)
        product_data = []
        
        for section in product_sections:
            section_data = process_table_section(image, section)
            if section_data:
                product_data.append(section_data)
        
        # 데이터 정리 및 저장
        if product_data:
            structured_data = clean_extracted_data(product_data, metadata)
            
            # 엑셀로 저장
            excel_filename = f"invoice_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            excel_path = os.path.join(result_folder, excel_filename)
            df = pd.DataFrame(structured_data)
            df.to_excel(excel_path, index=False)
            
            # 결과 업데이트
            result['excel_filename'] = excel_filename
            result['total_products'] = len(structured_data)
            result['data_preview'] = structured_data
        
        return result
    
    except Exception as e:
        print(f"[ERROR] 인보이스 처리 중 오류 발생: {str(e)}")
        print(traceback.format_exc())
        return result

def process_purchase_order(image_paths, options, result_folder):
    """발주서 문서 처리 함수"""
    result = {
        'excel_filename': '',
        'total_products': 0,
        'data_preview': []
    }
    
    try:
        # 첫 번째 페이지만 처리
        image_path = image_paths[0]
        
        # 전체 텍스트 추출
        full_text = extract_text_with_reading_order(image_path)
        
        # 텍스트 저장
        text_path = os.path.join(result_folder, "extracted_text.txt")
        with open(text_path, 'w', encoding='utf-8') as f:
            f.write(full_text)
        
        # 이미지 로드
        image = cv2.imread(image_path)
        
        # 메타데이터 추출 (브랜드, 시즌 등)
        metadata = extract_metadata(image, full_text)
        
        # 테이블 감지 및 데이터 추출
        product_data = extract_purchase_order_data(image, full_text, options)
        
        # 데이터 정리 및 저장
        if product_data:
            # 브랜드, 시즌 등 메타데이터 추가
            for item in product_data:
                for key, value in metadata.items():
                    if key not in item:
                        item[key] = value
            
            # 엑셀로 저장
            excel_filename = f"purchase_order_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            excel_path = os.path.join(result_folder, excel_filename)
            df = pd.DataFrame(product_data)
            df.to_excel(excel_path, index=False)
            
            # 결과 업데이트
            result['excel_filename'] = excel_filename
            result['total_products'] = len(product_data)
            result['data_preview'] = product_data
        
        return result
    
    except Exception as e:
        print(f"[ERROR] 발주서 처리 중 오류 발생: {str(e)}")
        print(traceback.format_exc())
        return result

def process_contract(image_paths, options, result_folder):
    """계약서 문서 처리 함수"""
    result = {
        'excel_filename': '',
        'total_products': 0,
        'data_preview': []
    }
    
    try:
        # 모든 페이지의 텍스트 추출
        full_text = ""
        for image_path in image_paths:
            page_text = extract_text_with_reading_order(image_path)
            full_text += page_text + "\n\n--- 페이지 구분 ---\n\n"
        
        # 텍스트 저장
        text_path = os.path.join(result_folder, "extracted_text.txt")
        with open(text_path, 'w', encoding='utf-8') as f:
            f.write(full_text)
        
        # 계약 정보 추출
        contract_info = extract_contract_info(full_text)
        
        # JSON으로 저장
        json_filename = f"contract_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        json_path = os.path.join(result_folder, json_filename)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(contract_info, f, ensure_ascii=False, indent=2)
        
        # 결과 업데이트
        result['excel_filename'] = json_filename
        result['total_products'] = 1  # 계약서는 일반적으로 하나의 문서
        result['data_preview'] = [contract_info]
        
        return result
    
    except Exception as e:
        print(f"[ERROR] 계약서 처리 중 오류 발생: {str(e)}")
        print(traceback.format_exc())
        return result

def process_general_document(image_paths, options, result_folder):
    """일반 문서 처리 함수"""
    result = {
        'excel_filename': '',
        'total_products': 0,
        'data_preview': []
    }
    
    try:
        # 모든 페이지의 텍스트 추출
        full_text = ""
        for image_path in image_paths:
            page_text = extract_text_with_reading_order(image_path)
            full_text += page_text + "\n\n--- 페이지 구분 ---\n\n"
        
        # 텍스트 저장
        text_path = os.path.join(result_folder, "extracted_text.txt")
        with open(text_path, 'w', encoding='utf-8') as f:
            f.write(full_text)
        
        # 문서 유형 다시 확인
        doc_type = detect_document_type_from_text(full_text)
        
        # 유형에 따라 처리 분기
        if doc_type == 'invoice':
            result = process_invoice(image_paths, options, result_folder)
        elif doc_type == 'purchase_order':
            result = process_purchase_order(image_paths, options, result_folder)
        elif doc_type == 'contract':
            result = process_contract(image_paths, options, result_folder)
        else:
            # 일반 문서로 처리
            document_info = {
                'text': full_text[:500] + "...",  # 미리보기 용도
                'text_path': text_path,
                'page_count': len(image_paths)
            }
            
            # JSON으로 저장
            json_filename = f"document_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            json_path = os.path.join(result_folder, json_filename)
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(document_info, f, ensure_ascii=False, indent=2)
            
            # 결과 업데이트
            result['excel_filename'] = json_filename
            result['total_products'] = 1
            result['data_preview'] = [document_info]
        
        return result
    
    except Exception as e:
        print(f"[ERROR] 일반 문서 처리 중 오류 발생: {str(e)}")
        print(traceback.format_exc())
        return result

def extract_metadata(image, full_text):
    """문서에서 메타데이터(브랜드, 시즌, 주문번호 등) 정보를 추출합니다."""
    metadata = {
        'brand': '',
        'season': '',
        'order_id': '',
        'start_ship': '',
        'complete_ship': ''
    }
    
    try:
        # 전체 텍스트에서 정보 추출
        lines = full_text.split('\n')
        
        # 브랜드 추출 - 다양한 브랜드명 패턴 시도
        brand_patterns = [
            r'TOGA\s+VIRILIS',
            r'WILD\s+DONKEY',
            r'ATHLETICS\s+FTWR',
            r'BASERANGE',
            r'NOU\s+NOU'
        ]
        
        for pattern in brand_patterns:
            for line in lines:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    metadata['brand'] = match.group(0)
                    break
            if metadata['brand']:
                break
        
        # 시즌 추출 - 20XXSS, 20XXFW 패턴
        season_pattern = re.compile(r'(20\d{2})(SS|FW)', re.IGNORECASE)
        for line in lines:
            match = season_pattern.search(line)
            if match:
                metadata['season'] = match.group(0).upper()
                break
        
        # 주문 ID 추출 - 다양한 패턴 시도
        order_patterns = [
            r'ORDER\s+(?:CONFIRMATION|NUMBER|ID|NO)[#:\s]*(\d+)',
            r'PO[#:\s]*(\d+)',
            r'ORDER[#:\s]*(\d+)',
            r'NO[#:\s.:]*(\d+)'
        ]
        
        for pattern in order_patterns:
            for line in lines:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    metadata['order_id'] = match.group(1)
                    break
            if metadata['order_id']:
                break
        
        # 선적 정보 추출
        ship_patterns = [
            (r'(?:START|BEGINNING)\s+SHIP\s*:?\s*(\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})', 'start_ship'),
            (r'(?:COMPLETE|END)\s+SHIP\s*:?\s*(\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})', 'complete_ship')
        ]
        
        for pattern, key in ship_patterns:
            for line in lines:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    metadata[key] = match.group(1)
                    break
        
        return metadata
    
    except Exception as e:
        print(f"[ERROR] 메타데이터 추출 중 오류 발생: {str(e)}")
        return metadata

def detect_document_type_from_text(text):
    """텍스트 내용을 기반으로 문서 유형을 감지합니다."""
    text_lower = text.lower()
    
    # 문서 유형 판별을 위한 키워드
    invoice_keywords = ['invoice', 'bill', 'tax', 'payment', '인보이스']
    purchase_order_keywords = ['purchase order', 'p.o', 'po#', '발주서', '주문서']
    contract_keywords = ['contract', 'agreement', '계약', '계약서']
    
    # 키워드 검색으로 문서 유형 판별
    for keyword in invoice_keywords:
        if keyword in text_lower:
            return 'invoice'
    
    for keyword in purchase_order_keywords:
        if keyword in text_lower:
            return 'purchase_order'
    
    for keyword in contract_keywords:
        if keyword in text_lower:
            return 'contract'
    
    # 기본값
    return 'unknown'

def detect_product_sections(image, full_text):
    """문서에서 각 상품 섹션을 감지합니다."""
    # 이미지를 그레이스케일로 변환
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # 이진화
    _, thresh = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY_INV)
    
    # 수평선 검출을 위한 커널
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (50, 1))
    horizontal_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel)
    
    # 수평선 위치 찾기
    h_projections = np.sum(horizontal_lines, axis=1)
    
    # 각 수평선의 y 좌표
    horizontal_positions = []
    for i in range(len(h_projections)):
        if h_projections[i] > 100:  # 임계값 조정 필요
            horizontal_positions.append(i)
    
    # 인접한 선 병합
    def merge_adjacent(positions, threshold=10):
        if not positions:
            return []
        
        merged = [positions[0]]
        for i in range(1, len(positions)):
            if positions[i] - merged[-1] <= threshold:
                continue
            merged.append(positions[i])
        
        return merged
    
    horizontal_positions = merge_adjacent(horizontal_positions)
    
    # 모델 코드 패턴 (예: AJ1323, AJ830 등) 찾기
    model_pattern = re.compile(r'AJ\d+')
    
    # OCR 수행
    _, buffer = cv2.imencode('.jpg', image)
    byte_img = buffer.tobytes()
    vision_image = vision.Image(content=byte_img)
    
    try:
        response = vision_client.text_detection(image=vision_image)
        
        # 모델 코드와 위치 정보 수집
        model_sections = []
        
        for text in response.text_annotations[1:]:  # 첫 번째는 전체 텍스트
            match = model_pattern.match(text.description)
            if match:
                # 텍스트의 중간 y 좌표
                vertices = text.bounding_poly.vertices
                y_coord = sum(vertex.y for vertex in vertices) / 4
                x_coord = sum(vertex.x for vertex in vertices) / 4
                
                # 해당 모델 행의 위치와 주변 수평선 찾기
                section_start = None
                section_end = None
                
                for i, pos in enumerate(horizontal_positions):
                    if pos > y_coord:
                        section_start = pos
                        # 다음 선이 있으면 섹션 끝으로 설정
                        if i + 1 < len(horizontal_positions):
                            section_end = horizontal_positions[i + 1]
                        break
                
                if section_start and section_end:
                    model_sections.append({
                        'model': text.description,
                        'y_pos': y_coord,
                        'x_pos': x_coord,
                        'section_start': section_start,
                        'section_end': section_end
                    })
        
        return model_sections
    
    except Exception as e:
        print(f"[ERROR] 상품 섹션 감지 중 오류 발생: {str(e)}")
        return []