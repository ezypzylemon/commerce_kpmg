/**
 * OCR 문서 관리 시스템 공통 JavaScript 함수
 */

// API 기본 URL - 환경에 따라 자동 설정
const API_BASE_URL = window.location.origin;

/**
 * API 요청 함수
 * @param {string} endpoint - API 엔드포인트 경로
 * @param {Object} options - fetch 옵션
 * @returns {Promise} 응답 객체 Promise
 */
async function apiRequest(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
    
    // 기본 헤더 설정
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    try {
        const response = await fetch(url, {
            ...options,
            headers
        });
        
        // 응답 에러 처리
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP 오류 ${response.status}`);
        }
        
        // 응답 데이터 반환
        if (response.headers.get('Content-Type')?.includes('application/json')) {
            return await response.json();
        }
        
        return await response.text();
    } catch (error) {
        console.error(`API 요청 오류 (${endpoint}):`, error);
        throw error;
    }
}

/**
 * 날짜를 사용자 친화적인 형식으로 변환
 * @param {string|Date} date - 변환할 날짜
 * @param {boolean} includeTime - 시간 포함 여부
 * @returns {string} 형식화된 날짜 문자열
 */
function formatDate(date, includeTime = false) {
    if (!date) return '';
    
    const dateObj = date instanceof Date ? date : new Date(date);
    
    // 날짜가 유효하지 않으면 빈 문자열 반환
    if (isNaN(dateObj.getTime())) return '';
    
    // 날짜 형식화
    const options = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    };
    
    if (includeTime) {
        options.hour = '2-digit';
        options.minute = '2-digit';
    }
    
    return dateObj.toLocaleDateString('ko-KR', options);
}

/**
 * 경과 시간을 사용자 친화적인 형식으로 변환
 * @param {string|Date} date - 기준 날짜
 * @returns {string} 경과 시간 문자열
 */
function timeAgo(date) {
    if (!date) return '';
    
    const dateObj = date instanceof Date ? date : new Date(date);
    
    // 날짜가 유효하지 않으면 빈 문자열 반환
    if (isNaN(dateObj.getTime())) return '';
    
    const now = new Date();
    const diffSeconds = Math.floor((now - dateObj) / 1000);
    
    if (diffSeconds < 60) {
        return '방금 전';
    }
    
    const diffMinutes = Math.floor(diffSeconds / 60);
    if (diffMinutes < 60) {
        return `${diffMinutes}분 전`;
    }
    
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) {
        return `${diffHours}시간 전`;
    }
    
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 30) {
        return `${diffDays}일 전`;
    }
    
    const diffMonths = Math.floor(diffDays / 30);
    if (diffMonths < 12) {
        return `${diffMonths}개월 전`;
    }
    
    const diffYears = Math.floor(diffMonths / 12);
    return `${diffYears}년 전`;
}

/**
 * 금액 형식화 함수
 * @param {number|string} amount - 형식화할 금액
 * @param {string} currency - 통화 기호
 * @returns {string} 형식화된 금액 문자열
 */
function formatCurrency(amount, currency = '₩') {
    if (amount === undefined || amount === null || amount === '') return '';
    
    // 문자열이면 숫자로 변환
    const numAmount = typeof amount === 'string' ? parseFloat(amount.replace(/[^\d.-]/g, '')) : amount;
    
    // 숫자가 유효하지 않으면 원래 값 반환
    if (isNaN(numAmount)) return amount;
    
    // 금액 형식화
    return `${currency} ${numAmount.toLocaleString('ko-KR')}`;
}

/**
 * 문서 상태 텍스트 변환 함수
 * @param {string} status - 문서 상태 코드
 * @returns {string} 상태 텍스트
 */
function translateStatus(status) {
    const statusMap = {
        'complete': '완료',
        'processing': '처리 중',
        'review': '검토 필요',
        'error': '오류',
        'pending': '대기 중',
        'delayed': '지연됨'
    };
    
    return statusMap[status] || status;
}

/**
 * 문서 유형 텍스트 변환 함수
 * @param {string} type - 문서 유형 코드
 * @returns {string} 유형 텍스트
 */
function translateDocType(type) {
    const typeMap = {
        'invoice': '인보이스',
        'purchase_order': '발주서',
        'contract': '계약서',
        'quotation': '견적서',
        'other': '기타'
    };
    
    return typeMap[type] || type;
}

/**
 * 알림 표시 함수
 * @param {string} message - 알림 메시지
 * @param {string} type - 알림 유형 ('success', 'error', 'warning', 'info')
 * @param {number} duration - 표시 시간 (밀리초)
 */
function showNotification(message, type = 'info', duration = 3000) {
    // 기존 알림 요소가 있으면 제거
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => {
        notification.remove();
    });
    
    // 알림 요소 생성
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // 아이콘 설정
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    else if (type === 'error') icon = 'exclamation-circle';
    else if (type === 'warning') icon = 'exclamation-triangle';
    
    // 알림 내용 생성
    notification.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <p>${message}</p>
        <button class="close-btn"><i class="fas fa-times"></i></button>
    `;
    
    // body에 알림 추가
    document.body.appendChild(notification);
    
    // 닫기 버튼 이벤트
    const closeBtn = notification.querySelector('.close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            notification.remove();
        });
    }
    
    // 자동 닫기
    setTimeout(() => {
        notification.classList.add('closing');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, duration);
}

/**
 * 문서 다운로드 함수
 * @param {string} filename - 다운로드할 파일명
 */
function downloadDocument(filename) {
    if (!filename) {
        showNotification('다운로드할 파일이 없습니다.', 'error');
        return;
    }
    
    window.location.href = `${API_BASE_URL}/download/${filename}`;
}

/**
 * 로컬 설정 저장 함수
 * @param {string} key - 설정 키
 * @param {any} value - 설정 값
 */
function saveLocalSetting(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error('설정 저장 오류:', error);
    }
}

/**
 * 로컬 설정 불러오기 함수
 * @param {string} key - 설정 키
 * @param {any} defaultValue - 기본 값
 * @returns {any} 설정 값
 */
function loadLocalSetting(key, defaultValue = null) {
    try {
        const value = localStorage.getItem(key);
        return value ? JSON.parse(value) : defaultValue;
    } catch (error) {
        console.error('설정 불러오기 오류:', error);
        return defaultValue;
    }
}

/**
 * 문서 로딩 완료 시 초기화 함수
 */
document.addEventListener('DOMContentLoaded', function() {
    // 알림 스타일 삽입
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            background-color: white;
            border-left: 4px solid #3182ce;
            border-radius: 4px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 1000;
            max-width: 400px;
            animation: slide-in 0.3s ease-out;
        }
        
        .notification.closing {
            animation: slide-out 0.3s ease-out forwards;
        }
        
        .notification.success {
            border-color: #2b8a3e;
        }
        
        .notification.error {
            border-color: #e53e3e;
        }
        
        .notification.warning {
            border-color: #e8590c;
        }
        
        .notification i {
            font-size: 1.2rem;
            color: #3182ce;
        }
        
        .notification.success i {
            color: #2b8a3e;
        }
        
        .notification.error i {
            color: #e53e3e;
        }
        
        .notification.warning i {
            color: #e8590c;
        }
        
        .notification p {
            flex-grow: 1;
            margin: 0;
            font-size: 0.9rem;
        }
        
        .notification .close-btn {
            background: none;
            border: none;
            font-size: 0.9rem;
            cursor: pointer;
            color: #a0aec0;
        }
        
        @keyframes slide-in {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slide-out {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    
    document.head.appendChild(style);
    
    // TODO: 추가 초기화 작업
});

// 전역으로 함수 노출
window.apiRequest = apiRequest;
window.formatDate = formatDate;
window.timeAgo = timeAgo;
window.formatCurrency = formatCurrency;
window.translateStatus = translateStatus;
window.translateDocType = translateDocType;
window.showNotification = showNotification;
window.downloadDocument = downloadDocument;
window.saveLocalSetting = saveLocalSetting;
window.loadLocalSetting = loadLocalSetting;