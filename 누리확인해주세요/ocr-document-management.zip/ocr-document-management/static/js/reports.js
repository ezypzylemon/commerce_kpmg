/**
 * OCR 문서 관리 시스템 보고서 관련 JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // 보고서 생성 버튼
    const generateReportBtn = document.getElementById('generateReportBtn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', showReportModal);
    }
    
    // 보고서 생성 모달이 없을 경우 생성
    if (!document.getElementById('reportModal')) {
        createReportModal();
    }
    
    // 차트는 이미 템플릿에서 처리하였으므로 추가 구현 불필요
});

/**
 * 보고서 생성 모달을 표시합니다
 */
function showReportModal() {
    $('#reportModal').modal('show');
}

/**
 * 보고서 생성 모달을 생성합니다
 */
function createReportModal() {
    const modalHTML = `
        <div class="modal fade" id="reportModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">보고서 생성</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="reportForm">
                            <div class="form-group">
                                <label for="reportType">보고서 유형</label>
                                <select class="form-control" id="reportType">
                                    <option value="monthly_ocr">월간 OCR 사용 보고서</option>
                                    <option value="order_summary">주문 요약 보고서</option>
                                    <option value="document_type">문서 유형 분석 보고서</option>
                                    <option value="efficiency">업무 효율성 보고서</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="reportPeriod">기간</label>
                                <select class="form-control" id="reportPeriod">
                                    <option value="last_month">지난 달</option>
                                    <option value="last_quarter">지난 분기</option>
                                    <option value="last_year">지난 해</option>
                                    <option value="custom">사용자 지정</option>
                                </select>
                            </div>
                            
                            <div id="customDateRange" style="display: none;">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="startDate">시작일</label>
                                            <input type="date" class="form-control" id="startDate">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="endDate">종료일</label>
                                            <input type="date" class="form-control" id="endDate">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="reportFormat">형식</label>
                                <select class="form-control" id="reportFormat">
                                    <option value="pdf">PDF</option>
                                    <option value="excel">Excel</option>
                                    <option value="csv">CSV</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">취소</button>
                        <button type="button" class="btn btn-primary" id="generateReport">보고서 생성</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // 모달을 body에 추가
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // 이벤트 핸들러 설정
    const reportPeriod = document.getElementById('reportPeriod');
    const customDateRange = document.getElementById('customDateRange');
    const generateReport = document.getElementById('generateReport');
    
    if (reportPeriod) {
        reportPeriod.addEventListener('change', function() {
            if (this.value === 'custom') {
                customDateRange.style.display = 'block';
            } else {
                customDateRange.style.display = 'none';
            }
        });
    }
    
    if (generateReport) {
        generateReport.addEventListener('click', function() {
            const reportType = document.getElementById('reportType').value;
            const reportPeriod = document.getElementById('reportPeriod').value;
            const reportFormat = document.getElementById('reportFormat').value;
            
            // 사용자 지정 기간 처리
            let startDate = null;
            let endDate = null;
            if (reportPeriod === 'custom') {
                startDate = document.getElementById('startDate').value;
                endDate = document.getElementById('endDate').value;
                
                if (!startDate || !endDate) {
                    alert('시작일과 종료일을 입력해주세요.');
                    return;
                }
            }
            
            // 보고서 생성 처리
            createReport(reportType, reportPeriod, reportFormat, startDate, endDate);
        });
    }
}

/**
 * 보고서를 생성합니다
 * @param {string} reportType - 보고서 유형
 * @param {string} reportPeriod - 보고서 기간
 * @param {string} reportFormat - 보고서 형식
 * @param {string} startDate - 시작일 (사용자 지정 기간일 경우)
 * @param {string} endDate - 종료일 (사용자 지정 기간일 경우)
 */
function createReport(reportType, reportPeriod, reportFormat, startDate, endDate) {
    // 진행 상태를 표시
    const generateReport = document.getElementById('generateReport');
    const originalText = generateReport.innerHTML;
    generateReport.disabled = true;
    generateReport.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> 처리 중...';
    
    // API 호출을 위한 파라미터 설정
    const params = {
        type: reportType,
        period: reportPeriod,
        format: reportFormat
    };
    
    if (reportPeriod === 'custom') {
        params.start_date = startDate;
        params.end_date = endDate;
    }
    
    // 실제로는 API.post('/api/reports/generate', params)와 같이 API 호출이 필요합니다
    // 여기서는 임시로 setTimeout을 사용하여 성공 처리
    setTimeout(() => {
        // 모달 닫기
        $('#reportModal').modal('hide');
        
        // 보고서 생성 완료 메시지
        alert('보고서가 성공적으로 생성되었습니다. 잠시 후 다운로드가 시작됩니다.');
        
        // 버튼 상태 복원
        generateReport.disabled = false;
        generateReport.innerHTML = originalText;
        
        // 페이지 새로고침
        window.location.reload();
    }, 2000);
}
