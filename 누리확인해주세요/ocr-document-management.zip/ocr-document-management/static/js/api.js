/**
 * OCR 문서 관리 시스템 API 호출 함수
 * common.js에 의존성이 있습니다. 이 파일보다 먼저 로드되어야 합니다.
 */

/**
 * 문서 목록 가져오기
 * @param {Object} filters - 필터 옵션 (선택 사항)
 * @returns {Promise<Array>} 문서 목록
 */
async function getDocuments(filters = {}) {
    try {
        // URL 쿼리 파라미터 생성
        const params = new URLSearchParams();
        
        if (filters.type) params.append('type', filters.type);
        if (filters.brand) params.append('brand', filters.brand);
        if (filters.search) params.append('search', filters.search);
        if (filters.dateFrom) params.append('date_from', filters.dateFrom);
        if (filters.dateTo) params.append('date_to', filters.dateTo);
        if (filters.status) params.append('status', filters.status);
        if (filters.limit) params.append('limit', filters.limit);
        
        const endpoint = `/api/documents${params.toString() ? '?' + params.toString() : ''}`;
        return await apiRequest(endpoint);
    } catch (error) {
        showNotification(`문서 목록을 가져오는 데 실패했습니다: ${error.message}`, 'error');
        return [];
    }
}

/**
 * 특정 문서 정보 가져오기
 * @param {string} documentId - 문서 ID
 * @returns {Promise<Object>} 문서 정보
 */
async function getDocument(documentId) {
    try {
        return await apiRequest(`/api/documents/${documentId}`);
    } catch (error) {
        showNotification(`문서 정보를 가져오는 데 실패했습니다: ${error.message}`, 'error');
        return null;
    }
}

/**
 * 문서 삭제하기
 * @param {string} documentId - 문서 ID
 * @returns {Promise<boolean>} 성공 여부
 */
async function deleteDocument(documentId) {
    try {
        await apiRequest(`/api/documents/${documentId}`, { method: 'DELETE' });
        showNotification('문서가 삭제되었습니다.', 'success');
        return true;
    } catch (error) {
        showNotification(`문서 삭제에 실패했습니다: ${error.message}`, 'error');
        return false;
    }
}

/**
 * 문서 업로드 및 OCR 처리
 * @param {FormData} formData - 업로드할 파일과 옵션을 포함한 FormData
 * @returns {Promise<Object>} 처리 결과
 */
async function uploadDocument(formData) {
    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP 오류 ${response.status}`);
        }
        
        const result = await response.json();
        showNotification('문서가 성공적으로 처리되었습니다.', 'success');
        return result;
    } catch (error) {
        showNotification(`문서 처리에 실패했습니다: ${error.message}`, 'error');
        throw error;
    }
}

/**
 * 문서 일치율 업데이트
 * @param {string} documentId - 문서 ID
 * @param {number} matchRate - 일치율
 * @returns {Promise<boolean>} 성공 여부
 */
async function updateDocumentMatchRate(documentId, matchRate) {
    try {
        await apiRequest(`/api/documents/${documentId}/match-rate`, {
            method: 'PUT',
            body: JSON.stringify({ match_rate: matchRate })
        });
        
        return true;
    } catch (error) {
        showNotification(`일치율 업데이트에 실패했습니다: ${error.message}`, 'error');
        return false;
    }
}

/**
 * 문서 비교하기
 * @param {string} document1Id - 첫 번째 문서 ID
 * @param {string} document2Id - 두 번째 문서 ID
 * @returns {Promise<Object>} 비교 결과
 */
async function compareDocuments(document1Id, document2Id) {
    try {
        const result = await apiRequest('/api/documents/compare', {
            method: 'POST',
            body: JSON.stringify({
                document1_id: document1Id,
                document2_id: document2Id
            })
        });
        
        return result;
    } catch (error) {
        showNotification(`문서 비교에 실패했습니다: ${error.message}`, 'error');
        return null;
    }
}

/**
 * 브랜드 목록 가져오기
 * @returns {Promise<Array>} 브랜드 목록
 */
async function getBrands() {
    try {
        const endpoint = '/api/brands';
        return await apiRequest(endpoint);
    } catch (error) {
        showNotification(`브랜드 목록을 가져오는 데 실패했습니다: ${error.message}`, 'error');
        return [];
    }
}

/**
 * 통계 정보 가져오기
 * @returns {Promise<Object>} 통계 정보
 */
async function getStatistics() {
    try {
        const endpoint = '/api/statistics';
        return await apiRequest(endpoint);
    } catch (error) {
        showNotification(`통계 정보를 가져오는 데 실패했습니다: ${error.message}`, 'error');
        return {};
    }
}

// 글로벌 스코프에 함수 노출
window.getDocuments = getDocuments;
window.getDocument = getDocument;
window.deleteDocument = deleteDocument;
window.uploadDocument = uploadDocument;
window.updateDocumentMatchRate = updateDocumentMatchRate;
window.compareDocuments = compareDocuments;
window.getBrands = getBrands;
window.getStatistics = getStatistics;