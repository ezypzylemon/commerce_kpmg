/**
 * OCR 문서 관리 시스템 문서 업로드 관련 JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    const uploadForm = document.getElementById('uploadForm');
    const uploadButton = document.getElementById('uploadButton');
    const previewContainer = document.getElementById('previewContainer');
    
    if (!dropzone || !fileInput || !uploadForm || !uploadButton) return;
    
    // 드래그 앤 드롭 이벤트 리스너
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    // 드래그 효과 스타일링
    ['dragenter', 'dragover'].forEach(eventName => {
        dropzone.addEventListener(eventName, () => {
            dropzone.classList.add('dragover');
        }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, () => {
            dropzone.classList.remove('dragover');
        }, false);
    });
    
    // 파일 드롭 처리
    dropzone.addEventListener('drop', e => {
        const files = e.dataTransfer.files;
        handleFiles(files);
    });
    
    // 클릭 기반 파일 선택
    dropzone.addEventListener('click', () => {
        fileInput.click();
    });
    
    fileInput.addEventListener('change', () => {
        handleFiles(fileInput.files);
    });
    
    // 파일 처리
    function handleFiles(files) {
        if (!files || files.length === 0) return;
        
        // 하나의 파일만 처리
        const file = files[0];
        
        // 지원하는 파일 형식 확인
        if (!isAllowedFileType(file.name)) {
            showError('지원하지 않는 파일 형식입니다. PDF, PNG, JPG, JPEG, TIFF 형식만 업로드할 수 있습니다.');
            return;
        }
        
        // 미리보기 생성
        createPreview(file);
        
        // 업로드 버튼 활성화
        uploadButton.disabled = false;
    }
    
    // 허용된 파일 형식 확인
    function isAllowedFileType(filename) {
        const allowedExtensions = ['.pdf', '.png', '.jpg', '.jpeg', '.tiff', '.tif'];
        return allowedExtensions.some(ext => filename.toLowerCase().endsWith(ext));
    }
    
    // 파일 미리보기 생성
    function createPreview(file) {
        previewContainer.innerHTML = '';
        
        const previewItem = document.createElement('div');
        previewItem.className = 'preview-item';
        
        // 파일 타입에 따라 다른 미리보기
        if (file.type.startsWith('image/')) {
            // 이미지 파일
            const img = document.createElement('img');
            img.file = file;
            previewItem.appendChild(img);
            
            const reader = new FileReader();
            reader.onload = (e) => {
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            // PDF 등 기타 파일 (아이콘으로 표시)
            const icon = document.createElement('div');
            icon.className = 'file-icon';
            
            if (file.name.toLowerCase().endsWith('.pdf')) {
                icon.innerHTML = '<svg width="64" height="64" fill="red" viewBox="0 0 16 16"><path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/><path d="M4.603 14.087a.81.81 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.68 7.68 0 0 1 1.482-.645 19.697 19.697 0 0 0 1.062-2.227 7.269 7.269 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.188-.012.396-.047.614-.084.51-.27 1.134-.52 1.794a10.954 10.954 0 0 0 .98 1.686 5.753 5.753 0 0 1 1.334.05c.364.066.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.856.856 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.712 5.712 0 0 1-.911-.95 11.651 11.651 0 0 0-1.997.406 11.307 11.307 0 0 1-1.02 1.51c-.292.35-.609.656-.927.787a.793.793 0 0 1-.58.029zm1.379-1.901c-.166.076-.32.156-.459.238-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361.01.022.02.036.026.044a.266.266 0 0 0 .035-.012c.137-.056.355-.235.635-.572a8.18 8.18 0 0 0 .45-.606zm1.64-1.33a12.71 12.71 0 0 1 1.01-.193 11.744 11.744 0 0 1-.51-.858 20.801 20.801 0 0 1-.5 1.05zm2.446.45c.15.163.296.3.435.41.24.19.407.253.498.256a.107.107 0 0 0 .07-.015.307.307 0 0 0 .094-.125.436.436 0 0 0 .059-.2.095.095 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a3.876 3.876 0 0 0-.612-.053zM8.078 7.8a6.7 6.7 0 0 0 .2-.828c.031-.188.043-.343.038-.465a.613.613 0 0 0-.032-.198.517.517 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822.024.111.054.227.09.346z"/></svg>';
            } else {
                icon.innerHTML = '<svg width="64" height="64" fill="gray" viewBox="0 0 16 16"><path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/></svg>';
            }
            
            previewItem.appendChild(icon);
        }
        
        const fileInfo = document.createElement('div');
        fileInfo.className = 'file-info';
        fileInfo.innerHTML = `
            <div class="file-name">${file.name}</div>
            <div class="file-size">${formatFileSize(file.size)}</div>
        `;
        previewItem.appendChild(fileInfo);
        
        const removeBtn = document.createElement('button');
        removeBtn.className = 'btn btn-sm btn-danger mt-2';
        removeBtn.innerHTML = '제거';
        removeBtn.addEventListener('click', () => {
            previewContainer.innerHTML = '';
            fileInput.value = '';
            uploadButton.disabled = true;
        });
        
        previewItem.appendChild(removeBtn);
        previewContainer.appendChild(previewItem);
    }
    
    // 파일 크기 형식화
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    // 오류 메시지 표시
    function showError(message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger alert-dismissible fade show mt-3';
        alert.innerHTML = `
            ${message}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        `;
        
        previewContainer.innerHTML = '';
        previewContainer.appendChild(alert);
    }
    
    // 업로드 버튼 클릭 처리
    uploadButton.addEventListener('click', () => {
        if (fileInput.files.length === 0) {
            showError('업로드할 파일을 선택해주세요.');
            return;
        }
        
        // 문서 유형 (선택 사항)
        const documentTypeSelect = document.getElementById('documentType');
        const documentType = documentTypeSelect ? documentTypeSelect.value : '';
        
        // 폼 데이터 생성 및 제출
        const formData = new FormData(uploadForm);
        if (documentType) {
            formData.append('document_type', documentType);
        }
        
        // 업로드 버튼 비활성화 및 로딩 상태로 변경
        uploadButton.disabled = true;
        uploadButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> 처리 중...';
        
        // 폼 제출
        uploadForm.submit();
    });
});
