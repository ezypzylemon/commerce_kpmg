/**
 * OCR 문서 관리 시스템 주문 관리 JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // 검색 기능
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    
    if (searchButton && searchInput) {
        searchButton.addEventListener('click', function() {
            window.location.href = `/orders?search=${encodeURIComponent(searchInput.value)}`;
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                window.location.href = `/orders?search=${encodeURIComponent(searchInput.value)}`;
            }
        });
    }
    
    // 주문 상세 보기 버튼
    const viewButtons = document.querySelectorAll('.view-order');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.getAttribute('data-id');
            if (orderId) {
                loadOrderDetails(orderId);
            }
        });
    });
    
    // 주문 편집 버튼
    const editButtons = document.querySelectorAll('.edit-order');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.getAttribute('data-id');
            if (orderId) {
                loadOrderDetails(orderId, true);
            }
        });
    });
    
    // 주문 업데이트 버튼
    const updateOrderButton = document.getElementById('updateOrder');
    if (updateOrderButton) {
        updateOrderButton.addEventListener('click', function() {
            const orderId = this.getAttribute('data-id');
            if (!orderId) return;
            
            // 폼 데이터 수집
            const orderData = {
                customer: document.getElementById('edit-customer').value,
                order_date: document.getElementById('edit-order-date').value,
                amount: parseFloat(document.getElementById('edit-amount').value),
                status: document.getElementById('edit-status').value
            };
            
            // API를 통해 주문 업데이트
            updateOrder(orderId, orderData);
        });
    }
    
    /**
     * 주문 상세 정보를 로드하고 모달을 표시합니다
     * @param {string} orderId - 주문 ID
     * @param {boolean} editable - 편집 가능 여부
     */
    function loadOrderDetails(orderId, editable = false) {
        const orderDetails = document.getElementById('orderDetails');
        if (!orderDetails) return;
        
        orderDetails.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"><span class="sr-only">로딩 중...</span></div></div>';
        
        // 주문 상세 정보 로드
        try {
            // API 호출 대신 임시 데이터 사용 (실제로는 API.orders.get(orderId)를 사용)
            // 실제 구현에서는 API 호출로 대체해야 합니다
            setTimeout(() => {
                const order = {
                    id: orderId,
                    order_number: `ORD-${orderId}`,
                    order_date: '2023-03-01',
                    customer: '(주)가나상사',
                    amount: 150000,
                    status: '신규',
                    filename: '주문서_20230301.pdf',
                    document_id: 10
                };
                
                renderOrderDetails(order, editable);
                
                // 모달 표시
                $('#orderModal').modal('show');
                
                // 업데이트 버튼에 주문 ID 저장
                const updateButton = document.getElementById('updateOrder');
                if (updateButton) {
                    updateButton.setAttribute('data-id', orderId);
                }
            }, 500);
        } catch (error) {
            orderDetails.innerHTML = `<div class="alert alert-danger">주문 정보를 불러오는 중 오류가 발생했습니다: ${error.message}</div>`;
        }
    }
    
    /**
     * 주문 상세 정보를 표시합니다
     * @param {Object} order - 주문 데이터
     * @param {boolean} editable - 편집 가능 여부
     */
    function renderOrderDetails(order, editable) {
        const orderDetails = document.getElementById('orderDetails');
        if (!orderDetails) return;
        
        if (editable) {
            // 편집 가능 폼
            orderDetails.innerHTML = `
                <form id="editOrderForm">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="edit-order-number">주문 번호</label>
                            <input type="text" id="edit-order-number" class="form-control" value="${order.order_number}" readonly>
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="edit-order-date">주문 일자</label>
                            <input type="date" id="edit-order-date" class="form-control" value="${order.order_date}">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="edit-customer">고객명</label>
                            <input type="text" id="edit-customer" class="form-control" value="${order.customer}">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="edit-amount">금액</label>
                            <input type="number" id="edit-amount" class="form-control" value="${order.amount}">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="edit-status">상태</label>
                            <select id="edit-status" class="form-control">
                                <option value="신규" ${order.status === '신규' ? 'selected' : ''}>신규</option>
                                <option value="처리중" ${order.status === '처리중' ? 'selected' : ''}>처리중</option>
                                <option value="완료" ${order.status === '완료' ? 'selected' : ''}>완료</option>
                                <option value="취소" ${order.status === '취소' ? 'selected' : ''}>취소</option>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="edit-file">원본 파일</label>
                            <div class="input-group">
                                <input type="text" id="edit-file" class="form-control" value="${order.filename}" readonly>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary" type="button" onclick="window.open('/documents/${order.document_id}', '_blank')">보기</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            `;
        } else {
            // 읽기 전용 상세 정보
            orderDetails.innerHTML = `
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tr>
                            <th width="30%">주문 번호</th>
                            <td>${order.order_number}</td>
                        </tr>
                        <tr>
                            <th>주문 일자</th>
                            <td>${formatDate(order.order_date)}</td>
                        </tr>
                        <tr>
                            <th>고객명</th>
                            <td>${order.customer}</td>
                        </tr>
                        <tr>
                            <th>금액</th>
                            <td>${formatCurrency(order.amount)}</td>
                        </tr>
                        <tr>
                            <th>상태</th>
                            <td>
                                <span class="badge ${getStatusClass(order.status)}">
                                    ${order.status}
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>원본 파일</th>
                            <td>
                                ${order.filename}
                                <a href="/documents/${order.document_id}" target="_blank" class="btn btn-sm btn-info ml-2">
                                    보기
                                </a>
                            </td>
                        </tr>
                    </table>
                </div>
            `;
        }
    }
    
    /**
     * 주문 상태에 따른 배지 클래스를 반환합니다
     * @param {string} status - 주문 상태
     * @returns {string} 배지 클래스
     */
    function getStatusClass(status) {
        switch (status) {
            case '완료': return 'badge-success';
            case '처리중': return 'badge-warning';
            case '취소': return 'badge-danger';
            default: return 'badge-secondary';
        }
    }
    
    /**
     * 주문 정보를 업데이트합니다
     * @param {string} orderId - 주문 ID
     * @param {Object} orderData - 업데이트할 주문 데이터
     */
    function updateOrder(orderId, orderData) {
        try {
            // API 호출 대신 임시 성공 처리 (실제로는 API.orders.update(orderId, orderData)를 사용)
            // 실제 구현에서는 API 호출로 대체해야 합니다
            console.log('주문 업데이트:', orderId, orderData);
            
            setTimeout(() => {
                // 성공 메시지
                alert('주문이 성공적으로 업데이트되었습니다.');
                
                // 모달 닫기
                $('#orderModal').modal('hide');
                
                // 페이지 새로고침
                window.location.reload();
            }, 500);
        } catch (error) {
            alert(`주문 업데이트 중 오류가 발생했습니다: ${error.message}`);
        }
    }
});
