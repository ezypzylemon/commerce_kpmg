/**
 * OCR 문서 관리 시스템 일정 관리 JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // 캘린더 초기화
    initCalendar();
    
    // 새 일정 추가 버튼
    const addEventBtn = document.getElementById('addEventBtn');
    if (addEventBtn) {
        addEventBtn.addEventListener('click', function() {
            // 모달 필드 초기화
            resetEventForm();
            
            // 모달 타이틀 설정
            document.getElementById('eventModalTitle').textContent = '일정 추가';
            
            // 삭제 버튼 숨기기
            const deleteBtn = document.getElementById('deleteEvent');
            if (deleteBtn) {
                deleteBtn.style.display = 'none';
            }
            
            // 기본 날짜 설정 (오늘)
            const today = new Date();
            const tomorrow = new Date();
            tomorrow.setDate(today.getDate() + 1);
            
            document.getElementById('eventStart').value = formatDateForInput(today);
            document.getElementById('eventEnd').value = formatDateForInput(tomorrow);
            
            // 모달 표시
            $('#eventModal').modal('show');
        });
    }
    
    // 일정 저장 버튼
    const saveEventBtn = document.getElementById('saveEvent');
    if (saveEventBtn) {
        saveEventBtn.addEventListener('click', function() {
            saveEvent();
        });
    }
    
    // 일정 삭제 버튼
    const deleteEventBtn = document.getElementById('deleteEvent');
    if (deleteEventBtn) {
        deleteEventBtn.addEventListener('click', function() {
            if (confirm('정말 이 일정을 삭제하시겠습니까?')) {
                const eventId = document.getElementById('eventId').value;
                if (eventId) {
                    deleteEvent(eventId);
                }
            }
        });
    }
    
    /**
     * FullCalendar 초기화
     */
    function initCalendar() {
        const calendarEl = document.getElementById('calendar');
        if (!calendarEl) return;
        
        const calendar = $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay'
            },
            locale: 'ko',
            buttonText: {
                today: '오늘',
                month: '월',
                week: '주',
                day: '일'
            },
            // 클릭 가능한 날짜 셀
            selectable: true,
            selectHelper: true,
            
            // 날짜 선택 시 일정 추가
            select: function(start, end) {
                resetEventForm();
                
                // 모달 타이틀 설정
                document.getElementById('eventModalTitle').textContent = '일정 추가';
                
                // 삭제 버튼 숨기기
                const deleteBtn = document.getElementById('deleteEvent');
                if (deleteBtn) {
                    deleteBtn.style.display = 'none';
                }
                
                // 선택한 날짜 설정
                document.getElementById('eventStart').value = formatDateForInput(start.toDate());
                document.getElementById('eventEnd').value = formatDateForInput(end.toDate());
                
                // 모달 표시
                $('#eventModal').modal('show');
            },
            
            // 일정 클릭 시 편집 모달
            eventClick: function(event) {
                // 모달 필드 초기화 후 이벤트 데이터로 채우기
                resetEventForm();
                
                // 모달 타이틀 설정
                document.getElementById('eventModalTitle').textContent = '일정 편집';
                
                // 이벤트 ID 설정
                document.getElementById('eventId').value = event.id;
                
                // 이벤트 데이터 채우기
                document.getElementById('eventTitle').value = event.title;
                document.getElementById('eventStart').value = formatDateForInput(event.start.toDate());
                if (event.end) {
                    document.getElementById('eventEnd').value = formatDateForInput(event.end.toDate());
                } else {
                    // 종료 시간이 없으면 시작 시간과 동일하게 설정
                    document.getElementById('eventEnd').value = formatDateForInput(event.start.toDate());
                }
                document.getElementById('eventDescription').value = event.description || '';
                
                // 삭제 버튼 표시
                const deleteBtn = document.getElementById('deleteEvent');
                if (deleteBtn) {
                    deleteBtn.style.display = 'inline-block';
                }
                
                // 모달 표시
                $('#eventModal').modal('show');
            },
            
            // 요일 및 날짜 형식
            dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
            dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
            monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
            monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
            
            // 기본 설정
            editable: true,
            eventLimit: true,
            
            // 이벤트 데이터 로드
            events: loadEvents
        });
    }
    
    /**
     * 이벤트 데이터를 로드합니다
     * @param {Function} callback - 이벤트 데이터를 받을 콜백 함수
     */
    function loadEvents(start, end, timezone, callback) {
        try {
            // API 호출 대신 임시 데이터 사용 (실제로는 API.events.list()를 사용)
            setTimeout(() => {
                const events = [
                    {
                        id: '1',
                        title: '문서 검토 회의',
                        start: '2023-03-15T10:00:00',
                        end: '2023-03-15T11:30:00',
                        description: '월간 문서 검토 및 처리 상태 점검',
                        color: '#3788d8'
                    },
                    {
                        id: '2',
                        title: 'OCR 시스템 업데이트',
                        start: '2023-03-20T14:00:00',
                        end: '2023-03-20T16:00:00',
                        description: '새로운 OCR 엔진 업데이트 작업',
                        color: '#28a745'
                    },
                    {
                        id: '3',
                        title: '거래처 미팅',
                        start: '2023-03-18',
                        allDay: true,
                        description: '주요 거래처와의 분기별 미팅',
                        color: '#ffc107'
                    }
                ];
                
                callback(events);
            }, 200);
        } catch (error) {
            console.error('이벤트 로드 중 오류 발생:', error);
            callback([]);
        }
    }
    
    /**
     * 이벤트 폼을 초기화합니다
     */
    function resetEventForm() {
        document.getElementById('eventId').value = '';
        document.getElementById('eventTitle').value = '';
        document.getElementById('eventStart').value = '';
        document.getElementById('eventEnd').value = '';
        document.getElementById('eventDescription').value = '';
    }
    
    /**
     * 날짜를 입력 필드에 맞는 형식으로 변환합니다
     * @param {Date} date - 변환할 날짜
     * @returns {string} 'YYYY-MM-DDTHH:MM' 형식의 문자열
     */
    function formatDateForInput(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    }
    
    /**
     * 새 이벤트를 저장하거나 기존 이벤트를 업데이트합니다
     */
    function saveEvent() {
        const eventId = document.getElementById('eventId').value;
        const title = document.getElementById('eventTitle').value;
        const start = document.getElementById('eventStart').value;
        const end = document.getElementById('eventEnd').value;
        const description = document.getElementById('eventDescription').value;
        
        if (!title || !start || !end) {
            alert('제목, 시작 일시, 종료 일시를 모두 입력해주세요.');
            return;
        }
        
        // 이벤트 데이터 생성
        const eventData = {
            title: title,
            start: start,
            end: end,
            description: description
        };
        
        try {
            if (eventId) {
                // 기존 이벤트 업데이트
                updateEvent(eventId, eventData);
            } else {
                // 새 이벤트 추가
                addEvent(eventData);
            }
        } catch (error) {
            alert(`일정 저장 중 오류가 발생했습니다: ${error.message}`);
        }
    }
    
    /**
     * 새 이벤트를 추가합니다
     * @param {Object} eventData - 이벤트 데이터
     */
    function addEvent(eventData) {
        // API 호출 대신 임시 성공 처리 (실제로는 API.events.add(eventData)를 사용)
        console.log('이벤트 추가:', eventData);
        
        setTimeout(() => {
            // 성공 메시지
            alert('일정이 성공적으로 추가되었습니다.');
            
            // 모달 닫기
            $('#eventModal').modal('hide');
            
            // 캘린더 새로고침
            $('#calendar').fullCalendar('refetchEvents');
        }, 500);
    }
    
    /**
     * 기존 이벤트를 업데이트합니다
     * @param {string} eventId - 이벤트 ID
     * @param {Object} eventData - 업데이트할 이벤트 데이터
     */
    function updateEvent(eventId, eventData) {
        // API 호출 대신 임시 성공 처리 (실제로는 API.events.update(eventId, eventData)를 사용)
        console.log('이벤트 업데이트:', eventId, eventData);
        
        setTimeout(() => {
            // 성공 메시지
            alert('일정이 성공적으로 업데이트되었습니다.');
            
            // 모달 닫기
            $('#eventModal').modal('hide');
            
            // 캘린더 새로고침
            $('#calendar').fullCalendar('refetchEvents');
        }, 500);
    }
    
    /**
     * 이벤트를 삭제합니다
     * @param {string} eventId - 이벤트 ID
     */
    function deleteEvent(eventId) {
        // API 호출 대신 임시 성공 처리 (실제로는 API.events.delete(eventId)를 사용)
        console.log('이벤트 삭제:', eventId);
        
        setTimeout(() => {
            // 성공 메시지
            alert('일정이 성공적으로 삭제되었습니다.');
            
            // 모달 닫기
            $('#eventModal').modal('hide');
            
            // 캘린더 새로고침
            $('#calendar').fullCalendar('refetchEvents');
        }, 500);
    }
});
