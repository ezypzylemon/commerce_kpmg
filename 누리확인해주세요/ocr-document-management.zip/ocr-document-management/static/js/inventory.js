/**
 * OCR 문서 관리 시스템 재고 관리 JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // 재고 항목 검색 기능
    const searchInput = document.getElementById('searchInventory');
    const searchButton = document.getElementById('searchButton');
    
    if (searchButton && searchInput) {
        searchButton.addEventListener('click', function() {
            window.location.href = `/inventory?search=${encodeURIComponent(searchInput.value)}`;
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                window.location.href = `/inventory?search=${encodeURIComponent(searchInput.value)}`;
            }
        });
    }
    
    // 재고 항목 편집 버튼
    const editButtons = document.querySelectorAll('.edit-item');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const itemId = this.getAttribute('data-id');
            if (itemId) {
                loadItemDetails(itemId);
            }
        });
    });
    
    // 재고 항목 삭제 버튼
    const deleteButtons = document.querySelectorAll('.delete-item');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const itemId = this.getAttribute('data-id');
            if (itemId) {
                // 삭제 확인 모달에 ID 저장
                document.getElementById('confirmDelete').setAttribute('data-id', itemId);
                // 삭제 확인 모달 표시
                $('#deleteConfirmModal').modal('show');
            }
        });
    });
    
    // 삭제 확인 버튼
    const confirmDelete = document.getElementById('confirmDelete');
    if (confirmDelete) {
        confirmDelete.addEventListener('click', function() {
            const itemId = this.getAttribute('data-id');
            if (itemId) {
                deleteItem(itemId);
                $('#deleteConfirmModal').modal('hide');
            }
        });
    }
    
    // 항목 추가/편집 모달의 저장 버튼
    const saveItemButton = document.getElementById('saveItem');
    if (saveItemButton) {
        saveItemButton.addEventListener('click', function() {
            const itemId = document.getElementById('itemId').value;
            const itemName = document.getElementById('itemName').value;
            const quantity = document.getElementById('quantity').value;
            
            if (!itemName || !quantity) {
                alert('항목명과 수량을 모두 입력해 주세요.');
                return;
            }
            
            const itemData = {
                item_name: itemName,
                quantity: parseInt(quantity)
            };
            
            if (itemId) {
                // 기존 항목 업데이트
                updateItem(itemId, itemData);
            } else {
                // 새 항목 추가
                addItem(itemData);
            }
        });
    }
    
    // 항목 추가 버튼
    const addItemBtn = document.getElementById('addItemBtn');
    if (addItemBtn) {
        addItemBtn.addEventListener('click', function() {
            // 항목 추가 모달 초기화
            document.getElementById('itemId').value = '';
            document.getElementById('itemName').value = '';
            document.getElementById('quantity').value = '';
            document.getElementById('itemModalTitle').textContent = '항목 추가';
            $('#itemModal').modal('show');
        });
    }
    
    /**
     * 재고 항목 상세 정보를 로드하고 편집 모달을 표시합니다
     * @param {string} itemId - 항목 ID
     */
    function loadItemDetails(itemId) {
        try {
            // API 호출 대신 임시 데이터 사용 (실제로는 API.inventory.get(itemId)를 사용)
            // 실제 구현에서는 API 호출로 대체해야 합니다
            setTimeout(() => {
                // 재고 항목 데이터 가져오기
                const items = Array.from(document.querySelectorAll('table tbody tr')).map(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length >= 3) {
                        return {
                            id: cells[0].textContent.trim(),
                            item_name: cells[1].textContent.trim(),
                            quantity: cells[2].textContent.trim()
                        };
                    }
                    return null;
                }).filter(item => item !== null);
                
                const item = items.find(i => i.id === itemId);
                
                if (item) {
                    // 모달 필드 채우기
                    document.getElementById('itemId').value = item.id;
                    document.getElementById('itemName').value = item.item_name;
                    document.getElementById('quantity').value = item.quantity;
                    document.getElementById('itemModalTitle').textContent = '항목 편집';
                    
                    // 모달 표시
                    $('#itemModal').modal('show');
                } else {
                    alert('항목 정보를 찾을 수 없습니다.');
                }
            }, 200);
        } catch (error) {
            alert(`항목 정보를 불러오는 중 오류가 발생했습니다: ${error.message}`);
        }
    }
    
    /**
     * 재고 항목을 추가합니다
     * @param {Object} itemData - 항목 데이터
     */
    function addItem(itemData) {
        try {
            // API 호출 대신 임시 성공 처리 (실제로는 API.inventory.add(itemData)를 사용)
            // 실제 구현에서는 API 호출로 대체해야 합니다
            console.log('항목 추가:', itemData);
            
            setTimeout(() => {
                // 성공 메시지
                alert('항목이 성공적으로 추가되었습니다.');
                
                // 모달 닫기
                $('#itemModal').modal('hide');
                
                // 페이지 새로고침
                window.location.reload();
            }, 500);
        } catch (error) {
            alert(`항목 추가 중 오류가 발생했습니다: ${error.message}`);
        }
    }
    
    /**
     * 재고 항목을 업데이트합니다
     * @param {string} itemId - 항목 ID
     * @param {Object} itemData - 업데이트할 항목 데이터
     */
    function updateItem(itemId, itemData) {
        try {
            // API 호출 대신 임시 성공 처리 (실제로는 API.inventory.update(itemId, itemData)를 사용)
            // 실제 구현에서는 API 호출로 대체해야 합니다
            console.log('항목 업데이트:', itemId, itemData);
            
            setTimeout(() => {
                // 성공 메시지
                alert('항목이 성공적으로 업데이트되었습니다.');
                
                // 모달 닫기
                $('#itemModal').modal('hide');
                
                // 페이지 새로고침
                window.location.reload();
            }, 500);
        } catch (error) {
            alert(`항목 업데이트 중 오류가 발생했습니다: ${error.message}`);
        }
    }
    
    /**
     * 재고 항목을 삭제합니다
     * @param {string} itemId - 항목 ID
     */
    function deleteItem(itemId) {
        try {
            // API 호출 대신 임시 성공 처리 (실제로는 API.inventory.delete(itemId)를 사용)
            // 실제 구현에서는 API 호출로 대체해야 합니다
            console.log('항목 삭제:', itemId);
            
            setTimeout(() => {
                // 성공 메시지
                alert('항목이 성공적으로 삭제되었습니다.');
                
                // 페이지 새로고침
                window.location.reload();
            }, 500);
        } catch (error) {
            alert(`항목 삭제 중 오류가 발생했습니다: ${error.message}`);
        }
    }
});
