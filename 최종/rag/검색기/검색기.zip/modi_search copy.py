# modi_search.py 수정
import numpy as np
from typing import Dict, List, Any, Tuple

def calculate_cosine_similarity(vecs1: List[List[float]], vecs2: List[List[float]], top_k=10):
    # 빈 벡터 리스트 체크
    if not vecs2:
        return [[] for _ in range(len(vecs1))]
    
    vecs2_arr = np.array(vecs2)
    vecs2_norm = np.linalg.norm(vecs2_arr, axis=1)
    
    results = []
    for vec1 in vecs1:
        vec = np.array(vec1)
        vec_norm = np.linalg.norm(vec)

        if vec_norm == 0:
            sim = np.zeros(len(vecs2))
        else:
            sim = np.dot(vecs2_arr, vec) / (vecs2_norm * vec_norm)        
        sim = np.nan_to_num(sim)

        # 결과 수가 top_k보다 적을 경우 처리
        top_k_actual = min(top_k, len(vecs2))
        if top_k_actual > 0:
            top_k_indices = np.argsort(sim)[-top_k_actual:][::-1]
            sim_top_k = [{'idx': i, 'sim_score': float(sim[i]), 'sim_vec': vecs2[i]} for i in top_k_indices]
        else:
            sim_top_k = []
        
        results.append(sim_top_k)
    
    return results

def search_similar_docs(keyword, top_k=5):
    """
    키워드와 유사한 문서를 검색하여 반환
    
    Args:
        keyword (str): 검색할 키워드
        top_k (int): 반환할 최대 문서 수
        
    Returns:
        list: 문서 ID 목록 (항상 리스트 형태로 반환)
    """
    similar_docs = []  # 항상 리스트로 초기화
    
    try:
        # 기존 검색 로직...
        
        # 검색 결과가 하나라도 항상 리스트로 감싸서 반환
        if isinstance(result, int):
            return [result]
        elif result is None:
            return []
        else:
            return list(result)  # 결과를 리스트로 변환하여 반환
            
    except Exception as e:
        logger.error(f"키워드 '{keyword}' 검색 오류: {e}")
        return []  # 오류 발생 시 빈 리스트 반환

def retrieve_relevant_docs(doc_ids: List[int], fashion_datas: List, musinsa_datas: List) -> List[Dict]:
    """문서 ID 목록을 기반으로 실제 문서 데이터 반환"""
    relevant_docs = []
    
    # 문서 ID와 데이터 매핑
    for doc_id in doc_ids:
        # 패션 데이터에서 검색
        for doc in fashion_datas:
            if doc._doc_id == doc_id:
                doc_dict = {
                    "id": doc._doc_id,
                    "title": doc._title if hasattr(doc, '_title') else "제목 없음",
                    "content": doc._content if hasattr(doc, '_content') else "내용 없음",
                    "source": doc._source if hasattr(doc, '_source') else "출처 없음",
                    "type": "fashion"
                }
                relevant_docs.append(doc_dict)
                print(f"패션 문서 찾음: {doc_dict['title'][:30]}...")
                break
                
        # 무신사 데이터에서도 검색
        for product in musinsa_datas:
            if product._doc_id == doc_id:
                product_dict = {
                    "id": product._doc_id,
                    "title": product._name if hasattr(product, '_name') else "제품명 없음",
                    "content": f"브랜드: {product._brand}, 가격: {product._price}, 카테고리: {product._category}",
                    "source": "무신사",
                    "type": "musinsa"
                }
                relevant_docs.append(product_dict)
                print(f"무신사 상품 찾음: {product_dict['title'][:30]}...")
                break
    
    print(f"검색된 문서 수: {len(relevant_docs)}")
    return relevant_docs