import os
import logging
from flask import Blueprint, request, jsonify, send_file
from werkzeug.utils import secure_filename
from .services.ocr_service import OCRProcessor

# 라우트 블루프린트 생성
orders_bp = Blueprint('orders', __name__)

# OCR 프로세서 초기화
ocr_processor = OCRProcessor()

# 파일 업로드 설정
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'uploads', 'temporary')
PROCESSED_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'uploads', 'processed')

# 폴더 생성 (존재하지 않는 경우)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_FOLDER, exist_ok=True)

# 허용된 파일 확장자
ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png'}

def allowed_file(filename):
    """파일 확장자 검증"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@orders_bp.route('/upload', methods=['POST'])
def upload_document():
    """문서 업로드 및 OCR 처리 엔드포인트"""
    try:
        # 파일이 없는 경우 처리
        if 'file' not in request.files:
            return jsonify({'error': '파일이 없습니다.'}), 400
        
        file = request.files['file']
        
        # 파일명이 비어있는 경우 처리
        if file.filename == '':
            return jsonify({'error': '선택된 파일이 없습니다.'}), 400
        
        # 파일 확장자 검증
        if file and allowed_file(file.filename):
            # 안전한 파일명 생성
            filename = secure_filename(file.filename)
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            
            # OCR 처리
            try:
                df_result, output_excel = ocr_processor.process_pdf(
                    filepath, 
                    output_dir=PROCESSED_FOLDER, 
                    verbose=False
                )
                
                if output_excel:
                    # 엑셀 파일 정보 반환
                    return jsonify({
                        'message': '문서 처리 완료',
                        'excel_filename': os.path.basename(output_excel),
                        'total_products': len(df_result),
                        'data_preview': df_result.head().to_dict(orient='records')
                    }), 200
                else:
                    return jsonify({'error': '문서 처리 중 오류가 발생했습니다.'}), 500
            
            except Exception as e:
                return jsonify({'error': f'문서 처리 중 오류: {str(e)}'}), 500
        
        else:
            return jsonify({'error': '허용되지 않은 파일 형식입니다.'}), 400
    
    except Exception as e:
        return jsonify({'error': '예상치 못한 오류가 발생했습니다.'}), 500

@orders_bp.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    """처리된 엑셀 파일 다운로드"""
    try:
        filepath = os.path.join(PROCESSED_FOLDER, filename)
        
        if os.path.exists(filepath):
            return send_file(filepath, 
                             as_attachment=True, 
                             download_name=filename,
                             mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        else:
            return jsonify({'error': '파일을 찾을 수 없습니다.'}), 404
    
    except Exception as e:
        return jsonify({'error': '다운로드 중 오류가 발생했습니다.'}), 500

@orders_bp.route('/documents', methods=['GET'])
def list_documents():
    """처리된 문서 목록 조회"""
    try:
        processed_files = [f for f in os.listdir(PROCESSED_FOLDER) if f.endswith('.xlsx')]
        return jsonify({
            'documents': processed_files,
            'total_count': len(processed_files)
        }), 200
    
    except Exception as e:
        return jsonify({'error': '문서 목록 조회 중 오류가 발생했습니다.'}), 500

@orders_bp.route('/health', methods=['GET'])
def health_check():
    """서버 상태 확인"""
    return jsonify({
        'status': 'healthy',
        'upload_folder': UPLOAD_FOLDER,
        'processed_folder': PROCESSED_FOLDER
    }), 200
