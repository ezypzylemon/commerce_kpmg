# 파일명: app.py
from flask import Flask, render_template, request, redirect, url_for, jsonify, g, logging as flask_logging
import os
import logging
import pandas as pd
from datetime import timedelta, datetime
from core.news_analyzer import NewsAnalyzer

# 기능 모듈 임포트
from app_modules import DashboardModule, NewsModule, MusinsaModule, MagazineModule

# NewsAnalyzer 인스턴스 생성
news_analyzer = NewsAnalyzer()

# 로깅 설정 - 디버그 레벨로 변경
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 데이터 디렉토리 생성
DATA_DIR = os.path.join('data')
os.makedirs(DATA_DIR, exist_ok=True)

# 정적 파일 디렉토리 생성
STATIC_DIR = os.path.join('static', 'images')
os.makedirs(STATIC_DIR, exist_ok=True)

# 경쟁사 이미지 디렉토리 생성
COMPETITOR_DIR = os.path.join('static', 'images', 'competitor')
os.makedirs(COMPETITOR_DIR, exist_ok=True)

# Flask 애플리케이션 생성
app = Flask(__name__, 
            static_folder='static',  # 프로젝트 루트의 static 폴더 지정
            static_url_path='/static')  # URL 경로 명시적 설정
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-for-testing')

# 정적 파일 요청 로깅 활성화
app.config['EXPLAIN_TEMPLATE_LOADING'] = True
app.config['DEBUG'] = True

# 기능 모듈 초기화
dashboard_module = DashboardModule()
news_module = NewsModule()
musinsa_module = MusinsaModule()
magazine_module = MagazineModule()

@app.before_request
def set_global_period():
    """모든 요청 전에 실행되는 함수, 전역 기간 설정"""
    # 정적 파일 요청은 처리하지 않음
    if request.path.startswith('/static/'):
        return
        
    # URL에서 period 파라미터 가져오기
    g.period = request.args.get('period', '7일')
    g.start_date = request.args.get('start_date')
    g.end_date = request.args.get('end_date')
    
    # 디버그 로깅 - 요청 정보
    logger.debug(f"요청 경로: {request.path}, 요청 인자: {dict(request.args)}")
    
    # 유효한 period 값 확인
    valid_periods = ['7일', '2주', '1개월', '3개월', '6개월', '1년', '1주일', 'custom']
    if g.period not in valid_periods:
        logger.warning(f"지원하지 않는 기간({g.period})이 요청되어 기본값(7일)으로 설정합니다.")
        g.period = '7일'
    
    # custom 기간 설정 시 start_date와 end_date 확인
    if g.period == 'custom' and (not g.start_date or not g.end_date):
        logger.warning("custom 기간이 선택되었으나 시작일 또는 종료일이 없어 기본값(7일)으로 설정합니다.")
        g.period = '7일'
        g.start_date = None
        g.end_date = None
    
    logger.info(f"전역 기간 설정: period={g.period}, start_date={g.start_date}, end_date={g.end_date}")

@app.before_request
def log_request_info():
    # 정적 파일 요청인 경우만 로깅
    if request.path.startswith('/static/'):
        logger.debug(f"정적 파일 요청: {request.path}")

# 정적 파일 디렉토리 인덱싱 요청 처리
@app.route('/static/')
@app.route('/static/<path:directory>')
def handle_directory_index(directory=''):
    """정적 파일 디렉토리 인덱스 요청 처리"""
    if not directory or directory.endswith('/'):
        logger.debug(f"정적 디렉토리 인덱스 요청 리다이렉트: {directory}")
        # 메인 페이지로 리다이렉트
        return redirect(url_for('dashboard'))
    return app.send_static_file(directory)

@app.route('/')
def index():
    """메인 페이지 - 대시보드로 리다이렉트"""
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    """통합 대시보드"""
    if g.period == 'custom' and g.start_date and g.end_date:
        return dashboard_module.render_dashboard(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date
        )
    
    return dashboard_module.render_dashboard(period=g.period)

@app.route('/news')
def news():
    """뉴스 분석 페이지"""
    try:
        # 입력값 검증
        if g.period == 'custom':
            if not (g.start_date and g.end_date) or g.start_date == 'None' or g.end_date == 'None':
                # 현재 날짜와 30일 전 날짜를 기본값으로 설정
                end_date = datetime.now().strftime('%Y-%m-%d')
                start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
                # 기본 기간으로 변경
                g.period = '1개월'
                logger.info(f"날짜 None 값 대신 기본값 사용: {start_date} ~ {end_date}")
            else:
                try:
                    start_date = pd.to_datetime(g.start_date).strftime('%Y-%m-%d')
                    end_date = pd.to_datetime(g.end_date).strftime('%Y-%m-%d')
                except Exception as e:
                    # 현재 날짜와 30일 전 날짜를 기본값으로 설정
                    end_date = datetime.now().strftime('%Y-%m-%d')
                    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
                    # 기본 기간으로 변경
                    g.period = '1개월'
                    logger.warning(f"날짜 형식이 올바르지 않아 기본값 사용: {e}")
                
            data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
            display_period = f"{start_date} ~ {end_date}"
            # ...기존 코드...
        else:
            if g.period not in ['7일', '2주', '1개월', '3개월', '6개월', '1년']:
                logger.warning(f"지원하지 않는 기간: {g.period}, 기본값 '7일'로 설정")
                g.period = '7일'
            data = news_module.data_loader.load_data_by_period(g.period)
            display_period = g.period

        # 현재 시간 추가 (JS 캐시 방지용)
        from datetime import datetime
        now = datetime.now()

        if data is None or data.empty:
            return render_template('news.html',
                               error="해당 기간에 데이터가 없습니다.",
                               period=g.period,
                               start_date=g.start_date,
                               end_date=g.end_date,
                               news_articles=[],
                               now=now)  # 현재 시간 추가

        # NewsAnalyzer에 데이터 설정
        news_module.analyzer.set_data(data)
        
        # 대시보드 데이터 생성
        dashboard_data = news_module.analyzer.generate_dashboard_data()
        
        # 최신 뉴스 기사
        latest_articles = data.sort_values('published', ascending=False).head(10).to_dict('records')
        
        # 상위 키워드 추출
        freq_results = news_module.analyzer.analyze_word_frequency()
        top_keywords = news_module.analyzer.get_top_words(freq_results, top_n=5)
        
        # 감성 분석
        sentiment_df = news_module.analyzer.calculate_article_sentiment()
        sentiment_results = news_module.analyzer.get_sentiment_distribution(sentiment_df)
        
        # 긍정/부정 기사
        positive_articles = sentiment_results['positive_articles'][:3] if sentiment_results else []
        negative_articles = sentiment_results['negative_articles'][:3] if sentiment_results else []
        
        return render_template('news.html',
                            period=g.period,
                            display_period=display_period,
                            start_date=g.start_date,
                            end_date=g.end_date,
                            latest_articles=latest_articles,
                            top_keywords=top_keywords,
                            keyword_trend=dashboard_data.get('keyword_trend'),
                            tfidf_wordcloud=dashboard_data.get('wordcloud'),
                            keyword_network=dashboard_data.get('keyword_network'),
                            positive_articles=positive_articles,
                            negative_articles=negative_articles,
                            now=now)  # 현재 시간 추가

    except ValueError as e:
        logger.error(f"입력값 오류: {e}")
        return render_template('news.html',
                            error=str(e),
                            period=g.period,
                            start_date=g.start_date,
                            end_date=g.end_date,
                            news_articles=[],
                            now=datetime.now())  # 현재 시간 추가
    except Exception as e:
        logger.error(f"뉴스 렌더링 중 오류 발생: {e}", exc_info=True)
        return render_template('news.html',
                            error="데이터 처리 중 오류가 발생했습니다.",
                            period=g.period,
                            start_date=g.start_date,
                            end_date=g.end_date,
                            news_articles=[],
                            now=datetime.now())  # 현재 시간 추가

@app.route('/musinsa')
def musinsa():
    """무신사 경쟁사 분석 페이지"""
    if g.period == 'custom' and g.start_date and g.end_date:
        return musinsa_module.render_musinsa(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date
        )
    
    return musinsa_module.render_musinsa(period=g.period)

@app.route('/magazine')
def magazine():
    """매거진 분석 페이지"""
    # URL에서 선택된 매거진 가져오기
    selected_magazines = request.args.getlist('magazine')
    
    # 선택된 매거진이 없으면 기본값 설정
    if not selected_magazines:
        selected_magazines = ['jentestore', 'marieclaire', 'vogue', 'wkorea', 'wwdkorea']
    
    if g.period == 'custom' and g.start_date and g.end_date:
        return magazine_module.render_magazine(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date,
            selected_magazines=selected_magazines
        )
    
    return magazine_module.render_magazine(
        period=g.period,
        selected_magazines=selected_magazines
    )

@app.route('/api/keywords')
def get_keywords():
    """키워드 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        data_loader = dashboard_module.data_loader
        
        if period == 'custom' and start_date and end_date:
            data = data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("키워드 API: 데이터가 없습니다.")
            return jsonify([])
        
        all_tokens = []
        if 'tokens' in data.columns:
            for tokens in data['tokens']:
                if isinstance(tokens, list):
                    all_tokens.extend(tokens)
        
        if not all_tokens:
            logger.warning("키워드 API: 토큰 데이터가 없습니다.")
            return jsonify([])
            
        token_counts = pd.Series(all_tokens).value_counts().head(20)
        
        keywords = [{'text': key, 'count': int(value)} 
                   for key, value in token_counts.items()]
        
        return jsonify(keywords)
    
    except Exception as e:
        logger.error(f"키워드 API 오류: {e}")
        return jsonify([])

@app.route('/api/magazine-data')
def get_magazine_data():
    """매거진 데이터 API"""
    try:
        magazine = request.args.get('magazine')
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        if not magazine:
            return jsonify({'error': '매거진 이름이 필요합니다.'})
        
        data_loader = magazine_module.data_loader
        
        if period == 'custom' and start_date and end_date:
            data = data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = data_loader.load_data_by_period(period)
            
        if data is None or data.empty:
            logger.warning(f"매거진 데이터 API: {magazine}에 대한 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        keywords = data_loader.get_magazine_keywords(magazine)
        card_news = data_loader.get_card_news(magazine)
        
        return jsonify({
            'keywords': keywords,
            'card_news': card_news
        })
    
    except Exception as e:
        logger.error(f"매거진 데이터 API 오류: {e}")
        return jsonify({'error': str(e)})

@app.route('/api/category-data')
def category_data():
    """카테고리별 데이터 API"""
    try:
        # 요청 파라미터 로깅 (디버깅용)
        logger.debug(f"카테고리 데이터 API 요청 파라미터: {dict(request.args)}")
        
        category_type = request.args.get('type', 'item')
        period = request.args.get('period') or g.period
        start_date = request.args.get('start_date') or g.start_date
        end_date = request.args.get('end_date') or g.end_date
        
        logger.info(f"카테고리 데이터 API: 타입={category_type}, 기간={period}, 시작일={start_date}, 종료일={end_date}")
        
        # 데이터 로더 초기화
        data_loader = magazine_module.data_loader
        
        # custom 기간인 경우 시작/종료일 설정
        if period == 'custom' and start_date and end_date:
            data_loader.custom_start_date = start_date
            data_loader.custom_end_date = end_date
            logger.info(f"직접 설정 기간 사용: {start_date} ~ {end_date}")
        
        # 카테고리 데이터 가져오기
        category_data = data_loader.get_category_data(category_type, period)
        
        if not category_data:
            # 샘플 데이터 반환 (데이터가 없는 경우)
            logger.warning(f"카테고리 데이터가 없습니다: 타입={category_type}, 기간={period}")
            return jsonify({
                'categories': ['데이터 없음'],
                'counts': [0],
                'growth_rates': [0],
                'prev_counts': [0]
            })
        
        return jsonify(category_data)
    
    except Exception as e:
        logger.error(f"카테고리 데이터 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

#뉴스 관련 라우트 추가
@app.route('/api/news/tfidf')
def api_news_tfidf():
    """뉴스 TF-IDF 분석 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        # NewsModule에서 데이터 로드
        data = None
        
        if period == 'custom' and start_date and end_date:
            data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = news_module.data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("TF-IDF API: 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        # NewsAnalyzer에 데이터 설정
        news_analyzer.set_data(data)
        
        # TF-IDF 분석 실행
        tfidf_results = news_analyzer.analyze_tfidf()
        
        # TF-IDF 차트 생성
        tfidf_chart = news_analyzer.generate_tfidf_chart(top_n=20, tfidf_results=tfidf_results)
        
        # TF-IDF 워드클라우드 생성
        tfidf_wordcloud = news_analyzer.generate_tfidf_wordcloud(tfidf_results=tfidf_results)
        
        # 결과 반환
        result = {
            'chart': tfidf_chart,
            'wordcloud': tfidf_wordcloud
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"TF-IDF API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.route('/api/news/topics')
def api_news_topics():
    """뉴스 토픽 모델링 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        # NewsModule에서 데이터 로드
        data = None
        
        if period == 'custom' and start_date and end_date:
            data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = news_module.data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("토픽 모델링 API: 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        # NewsAnalyzer에 데이터 설정
        news_analyzer.set_data(data)
        
        # 토픽 개수 파라미터
        n_topics = request.args.get('n_topics', default=5, type=int)
        
        # 토픽 모델링 실행
        topic_results = news_analyzer.analyze_topics(n_topics=n_topics)
        
        # 토픽 분포 정보
        topic_distribution = news_analyzer.get_topic_distribution(topic_results)
        
        # 토픽 차트 생성
        topic_charts = news_analyzer.generate_topic_chart(topic_results)
        
        # 결과 반환
        result = {
            'topic_info': topic_distribution['topic_info'] if topic_distribution else None,
            'charts': topic_charts
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"토픽 모델링 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.route('/api/news/sentiment')
def api_news_sentiment():
    """뉴스 감성 분석 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        # NewsModule에서 데이터 로드
        data = None
        
        if period == 'custom' and start_date and end_date:
            data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = news_module.data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("감성 분석 API: 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        # NewsAnalyzer에 데이터 설정
        news_analyzer.set_data(data)
        
        # 감성 분석 실행
        sentiment_df = news_analyzer.calculate_article_sentiment()
        
        # 감성 분포 정보
        sentiment_distribution = news_analyzer.get_sentiment_distribution(sentiment_df)
        
        # 감성 차트 생성
        sentiment_charts = news_analyzer.generate_sentiment_chart(sentiment_df)
        
        # 감성 워드클라우드 생성
        sentiment_wordclouds = news_analyzer.get_sentiment_wordcloud(sentiment_df)
        
        # 결과 반환
        result = {
            'sentiment_counts': sentiment_distribution['sentiment_counts'] if sentiment_distribution else None,
            'positive_articles': sentiment_distribution['positive_articles'][:3] if sentiment_distribution else [],
            'negative_articles': sentiment_distribution['negative_articles'][:3] if sentiment_distribution else [],
            'charts': sentiment_charts,
            'wordclouds': sentiment_wordclouds
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"감성 분석 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.route('/api/news/search')
def api_news_search():
    """뉴스 키워드 검색 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        # 검색 키워드
        keyword = request.args.get('keyword')
        if not keyword:
            return jsonify({'error': '검색 키워드가 필요합니다.'})
        
        # NewsModule에서 데이터 로드
        data = None
        
        if period == 'custom' and start_date and end_date:
            data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = news_module.data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("검색 API: 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        # 키워드로 기사 필터링
        if 'token_list' in data.columns:
            # 토큰에서 키워드 검색
            matches = data['token_list'].apply(lambda tokens: keyword in tokens if isinstance(tokens, list) else False)
        elif 'tokens' in data.columns:
            # 토큰에서 키워드 검색
            matches = data['tokens'].apply(lambda tokens: keyword in tokens if isinstance(tokens, list) else False)
        else:
            # 제목이나 내용에서 키워드 검색
            matches = (
                data['title'].str.contains(keyword, case=False, na=False) | 
                data['content'].str.contains(keyword, case=False, na=False)
            )
        
        matched_articles = data[matches].sort_values('upload_date', ascending=False)
        
        # 결과 반환
        result = {
            'keyword': keyword,
            'total_matches': len(matched_articles),
            'articles': matched_articles.head(10).to_dict('records')
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"검색 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.route('/api/news/network')
def api_news_network():
    """뉴스 단어 연관성 네트워크 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        # NewsModule에서 데이터 로드
        data = None
        
        if period == 'custom' and start_date and end_date:
            data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = news_module.data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("네트워크 API: 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        # NewsAnalyzer에 데이터 설정
        news_analyzer.set_data(data)
        
        # 연관성 분석 실행
        association_results = news_analyzer.analyze_word_association()
        
        # 중심 단어 추출
        central_words = news_analyzer.get_central_words(association_results)
        
        # 네트워크 그래프 생성
        network_graph = news_analyzer.generate_network_graph(association_results)
        
        # 결과 반환
        result = {
            'central_words': central_words,
            'network_graph': network_graph
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"네트워크 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.route('/api/news/trend')
def api_news_trend():
    """뉴스 시계열 트렌드 API"""
    try:
        # 요청 파라미터 직접 가져오기
        period = request.args.get('period', g.period)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # None 값 확인 및 처리
        if start_date == 'None' or start_date == '' or start_date is None:
            # 기본값으로 변경
            if period == 'custom':
                end_date = datetime.now().strftime('%Y-%m-%d')
                start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
                period = '1개월'  # 기본 기간으로 변경
                logger.info(f"API: 날짜 None 값 대신 기본값 사용: {start_date} ~ {end_date}")
            else:
                start_date = None
        
        if end_date == 'None' or end_date == '' or end_date is None:
            if period == 'custom':
                end_date = datetime.now().strftime('%Y-%m-%d')
                start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
                period = '1개월'  # 기본 기간으로 변경
                logger.info(f"API: 날짜 None 값 대신 기본값 사용: {start_date} ~ {end_date}")
            else:
                end_date = None
        
        logger.info(f"시계열 트렌드 API 호출: 기간={period}, 시작일={start_date}, 종료일={end_date}")
        
        # NewsModule에서 데이터 로드
        data = None
        
        if period == 'custom' and start_date and end_date:
            try:
                # 날짜 형식 검증
                pd.to_datetime(start_date)
                pd.to_datetime(end_date)
                data = news_module.data_loader.load_data_by_date_range(start_date, end_date)
            except Exception as e:
                logger.error(f"날짜 형식 오류: {e}")
                return jsonify({'error': f'날짜 형식이 올바르지 않습니다: {e}'})
        else:
            data = news_module.data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("트렌드 API: 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        # NewsAnalyzer에 데이터 설정
        news_analyzer.set_data(data)
        
        # 시계열 단위
        time_unit = request.args.get('unit', default='monthly')
        
        logger.info(f"시계열 분석 단위: {time_unit}")
        
        # 시계열 분석 실행
        time_data = news_analyzer.analyze_time_series()
        
        if not time_data:
            logger.warning("시계열 데이터 생성 실패")
            return jsonify({'error': '시계열 데이터를 생성할 수 없습니다.'})
        
        # 시계열 차트 생성
        time_chart = news_analyzer.generate_time_series_chart(time_data=time_data, time_unit=time_unit)
        
        # 키워드 트렌드 (상위 5개 키워드)
        top_keywords = []
        
        try:
            freq_results = news_analyzer.analyze_word_frequency()
            
            if not freq_results or 'word_counts' not in freq_results:
                logger.warning("단어 빈도 분석 결과가 없습니다.")
                return jsonify({
                    'time_chart': time_chart,
                    'error': '키워드 분석 결과가 없습니다.'
                })
            
            top_keywords = [word for word, _ in freq_results['word_counts'].most_common(5)]
            
            logger.info(f"상위 키워드: {top_keywords}")
            
            # 키워드 트렌드 분석 (개선된 버전)
            keyword_trend_data = news_analyzer.analyze_keyword_trend(top_keywords, time_unit)
            
            if keyword_trend_data is None:
                logger.warning("키워드 트렌드 데이터가 None입니다.")
                return jsonify({
                    'time_chart': time_chart,
                    'error': '키워드 트렌드 데이터를 생성할 수 없습니다.',
                    'top_keywords': top_keywords
                })
            
            # 데이터 구조 로깅
            if keyword_trend_data:
                logger.info(f"키워드 트렌드 데이터 구조: {list(keyword_trend_data.keys())}")
                if 'trends' in keyword_trend_data:
                    logger.info(f"트렌드 키: {list(keyword_trend_data['trends'].keys())}")
            
            # 키워드 트렌드 차트 생성 (개선된 버전)
            keyword_trend_chart = news_analyzer.generate_keyword_trend_chart(top_keywords, keyword_trend_data)
            
            if keyword_trend_chart is None:
                logger.warning("키워드 트렌드 차트 생성 실패")
                return jsonify({
                    'time_chart': time_chart,
                    'error': '키워드 트렌드 차트를 생성할 수 없습니다.',
                    'top_keywords': top_keywords
                })
            
            logger.info(f"키워드 트렌드 차트 생성 완료")
            
        except Exception as e:
            logger.error(f"키워드 트렌드 분석 중 오류: {e}", exc_info=True)
            return jsonify({
                'time_chart': time_chart,
                'error': f'키워드 트렌드 분석 중 오류: {str(e)}',
                'top_keywords': top_keywords
            })
        
        # 결과 반환
        result = {
            'time_chart': time_chart,
            'keyword_trend': keyword_trend_chart,
            'top_keywords': top_keywords
        }
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"트렌드 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.errorhandler(404)
def page_not_found(e):
    """404 오류 처리"""
    error_message = "페이지를 찾을 수 없습니다."
    
    # 정적 파일 요청 오류인 경우 더 구체적인 메시지 제공
    if request.path.startswith('/static/'):
        logger.warning(f"정적 파일을 찾을 수 없음: {request.path}")
        error_message = "요청한 리소스를 찾을 수 없습니다."
        
        # 특정 경로에 대한 문제인 경우 대안 제공
        if 'images/competitor/' in request.path:
            error_message += " 해당 기간에 생성된 차트가 없을 수 있습니다. 다른 기간을 선택해 보세요."
    
    return render_template('error.html', 
                          error=error_message,
                          error_code=404), 404

@app.errorhandler(500)
def server_error(e):
    """500 오류 처리"""
    logger.error(f"서버 오류 발생: {e}", exc_info=True)
    
    error_message = "서버 내부 오류가 발생했습니다."
    
    # 이미지 생성 또는 정적 파일 관련 오류인 경우
    if hasattr(e, 'description') and 'image' in str(e).lower():
        error_message = "차트 생성 중 오류가 발생했습니다. 데이터를 확인하거나 다른 기간을 선택해 보세요."
    
    return render_template('error.html', 
                          error=error_message,
                          error_code=500), 500

if __name__ == '__main__':
    app.run(debug=True, port=5001)