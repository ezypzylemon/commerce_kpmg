# 파일명: app.py
from flask import Flask, render_template, request, redirect, url_for, jsonify, g, logging as flask_logging
import os
import logging
import pandas as pd

# 기능 모듈 임포트
from app_modules import DashboardModule, NewsModule, MusinsaModule, MagazineModule

# 로깅 설정 - 디버그 레벨로 변경
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 데이터 디렉토리 생성
DATA_DIR = os.path.join('data')
os.makedirs(DATA_DIR, exist_ok=True)

# 정적 파일 디렉토리 생성
STATIC_DIR = os.path.join('static', 'images')
os.makedirs(STATIC_DIR, exist_ok=True)

# 경쟁사 이미지 디렉토리 생성
COMPETITOR_DIR = os.path.join('static', 'images', 'competitor')
os.makedirs(COMPETITOR_DIR, exist_ok=True)

# Flask 애플리케이션 생성
app = Flask(__name__, 
            static_folder='static',  # 프로젝트 루트의 static 폴더 지정
            static_url_path='/static')  # URL 경로 명시적 설정
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-for-testing')

# 정적 파일 요청 로깅 활성화
app.config['EXPLAIN_TEMPLATE_LOADING'] = True
app.config['DEBUG'] = True

# 기능 모듈 초기화
dashboard_module = DashboardModule()
news_module = NewsModule()
musinsa_module = MusinsaModule()
magazine_module = MagazineModule()

@app.before_request
def set_global_period():
    """모든 요청 전에 실행되는 함수, 전역 기간 설정"""
    # 정적 파일 요청은 처리하지 않음
    if request.path.startswith('/static/'):
        return
        
    # URL에서 period 파라미터 가져오기
    g.period = request.args.get('period', '7일')
    g.start_date = request.args.get('start_date')
    g.end_date = request.args.get('end_date')
    
    # 디버그 로깅 - 요청 정보
    logger.debug(f"요청 경로: {request.path}, 요청 인자: {dict(request.args)}")
    
    # 유효한 period 값 확인
    valid_periods = ['7일', '2주', '1개월', '3개월', '6개월', '1년', '1주일', 'custom']
    if g.period not in valid_periods:
        logger.warning(f"지원하지 않는 기간({g.period})이 요청되어 기본값(7일)으로 설정합니다.")
        g.period = '7일'
    
    # custom 기간 설정 시 start_date와 end_date 확인
    if g.period == 'custom' and (not g.start_date or not g.end_date):
        logger.warning("custom 기간이 선택되었으나 시작일 또는 종료일이 없어 기본값(7일)으로 설정합니다.")
        g.period = '7일'
        g.start_date = None
        g.end_date = None
    
    logger.info(f"전역 기간 설정: period={g.period}, start_date={g.start_date}, end_date={g.end_date}")

@app.before_request
def log_request_info():
    # 정적 파일 요청인 경우만 로깅
    if request.path.startswith('/static/'):
        logger.debug(f"정적 파일 요청: {request.path}")

# 정적 파일 디렉토리 인덱싱 요청 처리
@app.route('/static/')
@app.route('/static/<path:directory>')
def handle_directory_index(directory=''):
    """정적 파일 디렉토리 인덱스 요청 처리"""
    if not directory or directory.endswith('/'):
        logger.debug(f"정적 디렉토리 인덱스 요청 리다이렉트: {directory}")
        # 메인 페이지로 리다이렉트
        return redirect(url_for('dashboard'))
    return app.send_static_file(directory)

@app.route('/')
def index():
    """메인 페이지 - 대시보드로 리다이렉트"""
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    """통합 대시보드"""
    if g.period == 'custom' and g.start_date and g.end_date:
        return dashboard_module.render_dashboard(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date
        )
    
    return dashboard_module.render_dashboard(period=g.period)

@app.route('/news')
def news():
    """뉴스 분석 페이지"""
    if g.period == 'custom' and g.start_date and g.end_date:
        return news_module.render_news(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date
        )
    
    return news_module.render_news(period=g.period)

@app.route('/musinsa')
def musinsa():
    """무신사 경쟁사 분석 페이지"""
    if g.period == 'custom' and g.start_date and g.end_date:
        return musinsa_module.render_musinsa(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date
        )
    
    return musinsa_module.render_musinsa(period=g.period)

@app.route('/magazine')
def magazine():
    """매거진 분석 페이지"""
    # URL에서 선택된 매거진 가져오기
    selected_magazines = request.args.getlist('magazine')
    
    # 선택된 매거진이 없으면 기본값 설정
    if not selected_magazines:
        selected_magazines = ['jentestore', 'marieclaire', 'vogue', 'wkorea', 'wwdkorea']
    
    if g.period == 'custom' and g.start_date and g.end_date:
        return magazine_module.render_magazine(
            period='custom', 
            start_date=g.start_date, 
            end_date=g.end_date,
            selected_magazines=selected_magazines
        )
    
    return magazine_module.render_magazine(
        period=g.period,
        selected_magazines=selected_magazines
    )

@app.route('/api/keywords')
def get_keywords():
    """키워드 API"""
    try:
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        data_loader = dashboard_module.data_loader
        
        if period == 'custom' and start_date and end_date:
            data = data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = data_loader.load_data_by_period(period)
        
        if data is None or data.empty:
            logger.warning("키워드 API: 데이터가 없습니다.")
            return jsonify([])
        
        all_tokens = []
        if 'tokens' in data.columns:
            for tokens in data['tokens']:
                if isinstance(tokens, list):
                    all_tokens.extend(tokens)
        
        if not all_tokens:
            logger.warning("키워드 API: 토큰 데이터가 없습니다.")
            return jsonify([])
            
        token_counts = pd.Series(all_tokens).value_counts().head(20)
        
        keywords = [{'text': key, 'count': int(value)} 
                   for key, value in token_counts.items()]
        
        return jsonify(keywords)
    
    except Exception as e:
        logger.error(f"키워드 API 오류: {e}")
        return jsonify([])

@app.route('/api/magazine-data')
def get_magazine_data():
    """매거진 데이터 API"""
    try:
        magazine = request.args.get('magazine')
        period = g.period
        start_date = g.start_date
        end_date = g.end_date
        
        if not magazine:
            return jsonify({'error': '매거진 이름이 필요합니다.'})
        
        data_loader = magazine_module.data_loader
        
        if period == 'custom' and start_date and end_date:
            data = data_loader.load_data_by_date_range(start_date, end_date)
        else:
            data = data_loader.load_data_by_period(period)
            
        if data is None or data.empty:
            logger.warning(f"매거진 데이터 API: {magazine}에 대한 데이터가 없습니다.")
            return jsonify({'error': '데이터가 없습니다.'})
        
        keywords = data_loader.get_magazine_keywords(magazine)
        card_news = data_loader.get_card_news(magazine)
        
        return jsonify({
            'keywords': keywords,
            'card_news': card_news
        })
    
    except Exception as e:
        logger.error(f"매거진 데이터 API 오류: {e}")
        return jsonify({'error': str(e)})

@app.route('/api/category-data')
def category_data():
    """카테고리별 데이터 API"""
    try:
        # 요청 파라미터 로깅 (디버깅용)
        logger.debug(f"카테고리 데이터 API 요청 파라미터: {dict(request.args)}")
        
        category_type = request.args.get('type', 'item')
        period = request.args.get('period') or g.period
        start_date = request.args.get('start_date') or g.start_date
        end_date = request.args.get('end_date') or g.end_date
        
        logger.info(f"카테고리 데이터 API: 타입={category_type}, 기간={period}, 시작일={start_date}, 종료일={end_date}")
        
        # 데이터 로더 초기화
        data_loader = magazine_module.data_loader
        
        # custom 기간인 경우 시작/종료일 설정
        if period == 'custom' and start_date and end_date:
            data_loader.custom_start_date = start_date
            data_loader.custom_end_date = end_date
            logger.info(f"직접 설정 기간 사용: {start_date} ~ {end_date}")
        
        # 카테고리 데이터 가져오기
        category_data = data_loader.get_category_data(category_type, period)
        
        if not category_data:
            # 샘플 데이터 반환 (데이터가 없는 경우)
            logger.warning(f"카테고리 데이터가 없습니다: 타입={category_type}, 기간={period}")
            return jsonify({
                'categories': ['데이터 없음'],
                'counts': [0],
                'growth_rates': [0],
                'prev_counts': [0]
            })
        
        return jsonify(category_data)
    
    except Exception as e:
        logger.error(f"카테고리 데이터 API 오류: {e}", exc_info=True)
        return jsonify({'error': str(e)})

@app.errorhandler(404)
def page_not_found(e):
    """404 오류 처리"""
    error_message = "페이지를 찾을 수 없습니다."
    
    # 정적 파일 요청 오류인 경우 더 구체적인 메시지 제공
    if request.path.startswith('/static/'):
        logger.warning(f"정적 파일을 찾을 수 없음: {request.path}")
        error_message = "요청한 리소스를 찾을 수 없습니다."
        
        # 특정 경로에 대한 문제인 경우 대안 제공
        if 'images/competitor/' in request.path:
            error_message += " 해당 기간에 생성된 차트가 없을 수 있습니다. 다른 기간을 선택해 보세요."
    
    return render_template('error.html', 
                          error=error_message,
                          error_code=404), 404

@app.errorhandler(500)
def server_error(e):
    """500 오류 처리"""
    logger.error(f"서버 오류 발생: {e}", exc_info=True)
    
    error_message = "서버 내부 오류가 발생했습니다."
    
    # 이미지 생성 또는 정적 파일 관련 오류인 경우
    if hasattr(e, 'description') and 'image' in str(e).lower():
        error_message = "차트 생성 중 오류가 발생했습니다. 데이터를 확인하거나 다른 기간을 선택해 보세요."
    
    return render_template('error.html', 
                          error=error_message,
                          error_code=500), 500

if __name__ == '__main__':
    app.run(debug=True, port=5001)